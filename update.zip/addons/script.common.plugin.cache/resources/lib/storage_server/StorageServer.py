# -*- coding: utf-8 -*-
import hashlib
import json
import os
import socket
import string
import sys
import time
from contextlib import closing
import xbmc, xbmcvfs, xbmcaddon

class StorageServer:
    def __init__(self, table=None, timeout=24, instance=False):
        # טעינת הגדרות מה-addon (settings.xml)
        self.addon = xbmcaddon.Addon(id='script.common.plugin.cache')
        self.port = int(self.addon.getSetting("port") or 59994)
        self.path = xbmcvfs.translatePath('special://temp/')
        self.db_path = os.path.join(self.path, 'commoncache.db')
        self.socket_path = os.path.join(self.path, 'commoncache.socket')
        
        # זיהוי סוג המכשיר לאיזון משאבים
        self.is_android = xbmc.getCondVisibility('system.platform.android')
        
        # הגדרת באפר מאוזן: 16KB לסטרימר, 64KB למחשב
        self.network_buffer_size = 16384 if self.is_android else 65536 
        self.table = "universal_cache_v3"
        self.timeout = float(timeout) * 3600
        self.die = False
        self._startDB()

    def _startDB(self):
        import sqlite3
        # בסטרימר נשתמש ב-Timeout ארוך יותר למניעת נעילת DB
        db_timeout = 30 if self.is_android else 15
        try:
            self.conn = sqlite3.connect(self.db_path, check_same_thread=False, timeout=db_timeout)
            # אופטימיזציה קריטית להזרמה רציפה
            self.conn.execute("PRAGMA journal_mode=WAL;") 
            self.conn.execute("PRAGMA synchronous=NORMAL;") 
            
            # הגדרת מטמון זיכרון פנימי ל-DB (10MB לסטרימר, 40MB למחשב)
            db_cache = -10000 if self.is_android else -40000
            self.conn.execute(f"PRAGMA cache_size={db_cache};")
            
            self.curs = self.conn.cursor()
            self.curs.execute(f"CREATE TABLE IF NOT EXISTS {self.table} (name TEXT PRIMARY KEY, data TEXT)")
            self.conn.commit()
            return True
        except: return False

    def get(self, name):
        try:
            self.curs.execute(f"SELECT data FROM {self.table} WHERE name=?", (name,))
            row = self.curs.fetchone()
            return row[0] if row else None
        except: return None

    def set(self, name, data):
        try:
            self.curs.execute(f"INSERT OR REPLACE INTO {self.table} (name, data) VALUES (?, ?)", (name, data))
            self.conn.commit()
        except: pass

    def cacheFunction(self, funct, *args):
        """מאיץ כניסה לעונות וסדרות על ידי שמירת תוצאות API"""
        key_content = f"{funct.__name__}{repr(args)}"
        name = hashlib.md5(key_content.encode('utf-8')).hexdigest()
        
        cached = self.get(name)
        if cached:
            try:
                obj = json.loads(cached)
                if time.time() - obj['timestamp'] < self.timeout:
                    return obj['res']
            except: pass

        res = funct(*args)
        if res:
            self.set(name, json.dumps({'timestamp': time.time(), 'res': res}))
        return res

    def run(self):
        """הרצת השרת עם אופטימיזציית TCP למניעת תקיעות במוזיקה"""
        if sys.platform not in ["win32", "win10"] and not self.is_android:
            # POSIX Sockets (Linux)
            if xbmcvfs.exists(self.socket_path): xbmcvfs.delete(self.socket_path)
            server_sock = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
            address = self.socket_path
        else:
            # TCP Sockets (Windows/Android)
            server_sock = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            server_sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1) # ביטול השהיות Nagle
            address = ('127.0.0.1', self.port)

        try:
            server_sock.bind(address)
            server_sock.listen(20)
            server_sock.setblocking(False)
        except: return

        monitor = xbmc.Monitor()
        while not monitor.abortRequested() and not self.die:
            try:
                client, _ = server_sock.accept()
                with closing(client) as c:
                    raw_data = c.recv(self.network_buffer_size).decode('utf-8', 'ignore')
                    if raw_data:
                        data = json.loads(raw_data)
                        if data.get("action") == "get":
                            res = self.get(data.get("name"))
                            c.sendall(json.dumps(res).encode('utf-8'))
                        elif data.get("action") == "set":
                            self.set(data.get("name"), data.get("data"))
            except:
                time.sleep(0.01)

# הפעלה אוטומטית לפי ה-settings.xml של המשתמש
if xbmcaddon.Addon(id='script.common.plugin.cache').getSetting("autostart") == "true":
    import threading
    s = StorageServer(instance=True)
    threading.Thread(target=s.run, daemon=True).start()