import os
import shutil
import xbmc
import xbmcgui
import xbmcvfs

TELEMEDIA_ID = "plugin.video.telemedia"


# =========================================================================
# פונקציות ניתוב וניהול נתיבים (Path Management)
# =========================================================================

def get_target_addon_data_path():
    try:
        target_path = xbmcvfs.translatePath(f"special://profile/addon_data/{TELEMEDIA_ID}")
        if isinstance(target_path, bytes):
            target_path = target_path.decode("utf-8")
        return os.path.normpath(target_path)
    except Exception as e:
        xbmc.log(f"BackupScript: Failed to resolve path: {str(e)}", xbmc.LOGERROR)
        return None


def select_directory_dialog(title_message):
    try:
        dialog = xbmcgui.Dialog()
        selected_dir = dialog.browse(0, title_message, 'local')
        if isinstance(selected_dir, bytes):
            selected_dir = selected_dir.decode("utf-8")
        if selected_dir:
            return os.path.normpath(selected_dir)
    except Exception as e:
        xbmc.log(f"BackupScript: Dialog browse failed: {str(e)}", xbmc.LOGERROR)
    return None


def adjust_android_usb_path(chosen_path):
    # פעולה אחת: התאמת נתיב כונן חיצוני באנדרואיד לנתיב מורשה (Scoped Storage Bypass)
    # נבדוק אם אנו באנדרואיד ואם נבחר כונן חיצוני (בדרך כלל תחת /storage/ או /mnt/)
    if xbmc.getCondVisibility("System.Platform.Android"):
        # הסרה של לוכסנים מיותרים בקצוות לצורך בדיקה נקיון
        clean_path = chosen_path.rstrip(os.sep)
        
        # אם המשתמש בחר בשורש של כונן חיצוני (למשל /storage/XXXX-XXXX)
        if "/storage/" in clean_path and len(clean_path.split(os.sep)) <= 3:
            android_writable_path = os.path.join(clean_path, "Android", "data", "org.xbmc.kodi", "files")
            xbmc.log(f"BackupScript: Android USB detected. Redirecting to writable path: {android_writable_path}", xbmc.LOGINFO)
            return os.path.normpath(android_writable_path)
            
    return chosen_path


# =========================================================================
# פונקציות עזר לניהול קבצים (Fault-Tolerant File Operations)
# =========================================================================

def copy_file_fault_tolerant(src_file, dst_file):
    try:
        shutil.copy2(src_file, dst_file)
        return True
    except PermissionError:
        xbmc.log(f"BackupScript: Skipped locked file (Permission Denied): {src_file}", xbmc.LOGWARNING)
        return False
    except Exception as e:
        xbmc.log(f"BackupScript: Failed to copy {src_file}: {str(e)}", xbmc.LOGERROR)
        return False


def copy_tree_fault_tolerant(src_dir, dst_dir):
    os.makedirs(dst_dir, exist_ok=True)
    for root, dirs, files in os.walk(src_dir):
        relative_path = os.path.relpath(root, src_dir)
        target_root = os.path.normpath(os.path.join(dst_dir, relative_path))
        
        for d in dirs:
            os.makedirs(os.path.join(target_root, d), exist_ok=True)
            
        for f in files:
            src_file = os.path.join(root, f)
            dst_file = os.path.join(target_root, f)
            copy_file_fault_tolerant(src_file, dst_file)


# =========================================================================
# פונקציות הליבה של התהליכים (Process Flows)
# =========================================================================

def execute_backup():
    source = get_target_addon_data_path()
    if not source or not os.path.exists(source):
        xbmcgui.Dialog().ok("שגיאה", "תיקיית המקור של טלמדיה לא נמצאה.")
        return

    chosen_dir = select_directory_dialog('בחר את כונן ה-USB או תיקיית היעד')
    if not chosen_dir:
        return

    # תיקון נתיב אוטומטי אם מדובר ב-USB על אנדרואיד
    chosen_dir = adjust_android_usb_path(chosen_dir)

    final_destination = os.path.join(chosen_dir, TELEMEDIA_ID)
    
    dp = xbmcgui.DialogProgress()
    dp.create("מערכת גיבוי", "מבצע גיבוי חסין תקלות, אנא המתן...")
    
    try:
        if os.path.exists(final_destination):
            try: shutil.rmtree(final_destination)
            except Exception: pass
                
        copy_tree_fault_tolerant(source, final_destination)
        dp.close()
        xbmcgui.Dialog().ok("גיבוי מוצלח", f"הגיבוי הסתיים בהצלחה!\nהספרייה נשמרה ב:\n{final_destination}")
    except Exception as e:
        dp.close()
        xbmc.log(f"BackupScript: Critical backup error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("שגיאה", f"הגיבוי נכשל: {str(e)}")


def execute_restore():
    target_addon_data = get_target_addon_data_path()
    if not target_addon_data:
        xbmcgui.Dialog().ok("שגיאה", "לא ניתן לחשב את נתיב היעד בקוד.")
        return
    
    chosen_backup_dir = select_directory_dialog('בחר את תיקיית הגיבוי או כונן ה-USB')
    if not chosen_backup_dir:
        return

    # תיקון נתיב אוטומטי אם המשתמש בחר בשורש ה-USB באנדרואיד בשחזור
    chosen_backup_dir = adjust_android_usb_path(chosen_backup_dir)

    # אם המשתמש בחר בתיקיית האב שמכילה את plugin.video.telemedia ולא בה ישירות
    if TELEMEDIA_ID not in chosen_backup_dir and os.path.exists(os.path.join(chosen_backup_dir, TELEMEDIA_ID)):
        chosen_backup_dir = os.path.join(chosen_backup_dir, TELEMEDIA_ID)

    if not os.path.exists(chosen_backup_dir):
        xbmcgui.Dialog().ok("שגיאת שחזור", f"לא נמצא גיבוי תקין של {TELEMEDIA_ID} בנתיב שנבחר.")
        return

    confirm = xbmcgui.Dialog().yesno("אישור שחזור", "האם אתה בטוח שברצונך לשחזר?\nכל המידע הנוכחי בקודי יידרס בשלמותו.")
    if not confirm:
        return

    dp = xbmcgui.DialogProgress()
    dp.create("מערכת שחזור", "משחזר קבצים, אנא המתן...")
    
    try:
        if os.path.exists(target_addon_data):
            for root, dirs, files in os.walk(target_addon_data, topdown=False):
                for f in files:
                    try: os.remove(os.path.join(root, f))
                    except Exception: pass
                for d in dirs:
                    try: os.rmdir(os.path.join(root, d))
                    except Exception: pass
                    
        copy_tree_fault_tolerant(chosen_backup_dir, target_addon_data)
        
        dp.close()
        xbmcgui.Dialog().ok("שחזור מוצלח", "השחזור הסתיים בהצלחה!\n\nמומלץ לבצע 'אלץ עצירה' לקודי כעת.")
    except Exception as e:
        dp.close()
        xbmc.log(f"BackupScript: Critical restore error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("שגיאה", f"השחזור נכשל: {str(e)}")


# =========================================================================
# תפריט ראשי ונקודת כניסה (Main Menu & Entry Point)
# =========================================================================

def show_main_menu():
    xbmc.sleep(1200)
    options = ["1. Backup Telemedia Data", "2. Restore Telemedia Data"]
    
    try:
        selection = xbmcgui.Dialog().select("Telemedia Manager", options)
        if selection == 0:
            execute_backup()
        elif selection == 1:
            execute_restore()
    except Exception as e:
        xbmc.log(f"BackupScript: Critical menu error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("שגיאה", f"לא ניתן להציג את התפריט:\n{str(e)}")


if __name__ == "__main__":
    show_main_menu()