#!/usr/bin/python
# -*- coding: utf-8 -*-

'''optimized caching system for Kodi 21+ with Async Background Support'''

import xbmcvfs
import xbmcgui
import xbmc
import xbmcaddon
import datetime
import time
import sqlite3
import json
import threading
from functools import reduce

ADDON_ID = "script.module.simplecache"

class SimpleCache(object):
    enable_mem_cache = True
    _auto_clean_interval = datetime.timedelta(hours=4)
    _db_connection = None
    _db_lock = threading.Lock() 

    def __init__(self):
        self._win = xbmcgui.Window(10000)
        self._monitor = xbmc.Monitor()
        self._mem_local_cache = {} 
        self.check_cleanup()
        self._log_msg("Initialized: High-Performance Async Mode")

    def _get_database(self):
        '''חיבור אופטימלי עם מיפוי זיכרון למניעת תקיעות'''
        with self._db_lock:
            if self._db_connection:
                return self._db_connection

            addon = xbmcaddon.Addon(ADDON_ID)
            dbpath = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
            if not xbmcvfs.exists(dbpath):
                xbmcvfs.mkdirs(dbpath)
            
            dbfile = f"{dbpath}simplecache.db"
            try:
                conn = sqlite3.connect(dbfile, timeout=60, isolation_level=None)
                conn.execute('PRAGMA journal_mode = WAL')
                conn.execute('PRAGMA synchronous = NORMAL')
                conn.execute('PRAGMA mmap_size = 31457280') # 30MB MMAP
                conn.execute('CREATE TABLE IF NOT EXISTS simplecache(id TEXT UNIQUE, expires INTEGER, data TEXT, checksum INTEGER)')
                self._db_connection = conn
                return conn
            except Exception as e:
                self._log_msg(f"DB Error: {e}", xbmc.LOGWARNING)
                return None

    def get(self, endpoint, checksum="", json_data=True):
        '''שליפה רב-שכבתית מהירה'''
        checksum = self._get_checksum(checksum)
        cur_time = self._get_timestamp(datetime.datetime.now())
        
        # שלב 1: RAM מקומי (L1)
        if self.enable_mem_cache and endpoint in self._mem_local_cache:
            expires, data, csum = self._mem_local_cache[endpoint]
            if expires > cur_time and (not checksum or checksum == csum):
                return data

        # שלב 2: Window Property (L2)
        res = self._get_mem_cache(endpoint, checksum, cur_time)
        if res is not None:
            return res

        # שלב 3: Database (L3)
        return self._get_db_cache(endpoint, checksum, cur_time)

    def set(self, endpoint, data, checksum="", expiration=datetime.timedelta(days=30)):
        '''שמירה אסינכרונית - ביצועים מקסימליים'''
        checksum = self._get_checksum(checksum)
        expires = self._get_timestamp(datetime.datetime.now() + expiration)

        # עדכון מיידי בזיכרון ה-RAM
        if self.enable_mem_cache:
            self._mem_local_cache[endpoint] = (expires, data, checksum)
            self._win.setProperty(endpoint, json.dumps((expires, data, checksum)))

        # כתיבה לדיסק בשרשור רקע נפרד
        threading.Thread(target=self._async_db_set, args=(endpoint, checksum, expires, data), daemon=True).start()

    def _async_db_set(self, endpoint, checksum, expires, data):
        try:
            db = self._get_database()
            if db:
                db.execute("INSERT OR REPLACE INTO simplecache(id, expires, data, checksum) VALUES (?, ?, ?, ?)",
                           (endpoint, expires, json.dumps(data), checksum))
        except:
            pass

    def _get_db_cache(self, endpoint, checksum, cur_time):
        db = self._get_database()
        if not db: return None
        try:
            cursor = db.execute("SELECT expires, data, checksum FROM simplecache WHERE id = ?", (endpoint,))
            row = cursor.fetchone()
            if row and row[0] > cur_time:
                if not checksum or row[2] == checksum:
                    data = json.loads(row[1])
                    self._mem_local_cache[endpoint] = (row[0], data, row[2])
                    return data
        except: pass
        return None

    def _get_mem_cache(self, endpoint, checksum, cur_time):
        raw = self._win.getProperty(endpoint)
        if not raw: return None
        try:
            expires, data, csum = json.loads(raw)
            if expires > cur_time and (not checksum or checksum == csum):
                return data
        except: pass
        return None

    def _get_checksum(self, stringinput):
        if not stringinput: return 0
        return reduce(lambda x, y: x + y, map(ord, str(stringinput)))

    def _get_timestamp(self, date_time):
        return int(time.mktime(date_time.timetuple()))

    def _log_msg(self, msg, level=xbmc.LOGDEBUG):
        xbmc.log(f"SimpleCache-Async -> {msg}", level)

    def check_cleanup(self):
        last = self._win.getProperty("simplecache.last_clean")
        if not last or (float(last) + self._auto_clean_interval.total_seconds() < time.time()):
            threading.Thread(target=self._do_cleanup, daemon=True).start()

    def _do_cleanup(self):
        db = self._get_database()
        if db:
            now = self._get_timestamp(datetime.datetime.now())
            db.execute("DELETE FROM simplecache WHERE expires < ?", (now,))
            db.execute("VACUUM")
            self._win.setProperty("simplecache.last_clean", str(time.time()))

# --- Decorator המעטפת לשימוש קל ---

def use_cache(cache_hours=72):
    def decorator(func):
        def decorated(*args, **kwargs):
            method_class = args[0]
            cache_key = f"{method_class.__class__.__name__}.{func.__name__}"
            for item in args[1:]:
                cache_key += f".{item}"
            
            if kwargs.get("ignore_cache") or getattr(method_class, "ignore_cache", False):
                return func(*args, **kwargs)

            cachedata = method_class.cache.get(cache_key)
            if cachedata is not None:
                return cachedata
            
            result = func(*args, **kwargs)
            method_class.cache.set(cache_key, result, expiration=datetime.timedelta(hours=cache_hours))
            return result
        return decorated
    return decorator