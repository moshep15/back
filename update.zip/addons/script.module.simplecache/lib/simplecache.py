#!/usr/bin/python
# -*- coding: utf-8 -*-

'''provides an optimized stateless caching system for Kodi 21+ addons'''

import xbmcvfs
import xbmcgui
import xbmc
import xbmcaddon
import datetime
import time
import sqlite3
import json
import ast
from functools import reduce

ADDON_ID = "script.module.simplecache"

class SimpleCache(object):
    '''optimized caching system for Kodi 21 (Python 3)'''
    enable_mem_cache = True
    data_is_json = True  # שינוי ל-True כברירת מחדל לביצועים
    global_checksum = None
    _exit = False
    _auto_clean_interval = datetime.timedelta(hours=4)
    _win = None
    _busy_tasks = []
    _db_connection = None # שמירת חיבור פתוח

    def __init__(self):
        '''Initialize our caching class'''
        self._win = xbmcgui.Window(10000)
        self._monitor = xbmc.Monitor()
        self._mem_local_cache = {} # שכבת זיכרון מהירה נוספת
        self.check_cleanup()
        self._log_msg("Initialized with WAL mode and JSON support")

    def close(self):
        self._exit = True
        while self._busy_tasks and not self._monitor.abortRequested():
            xbmc.sleep(25)
        if self._db_connection:
            self._db_connection.close()
        self._log_msg("Closed")

    def __del__(self):
        if not self._exit:
            self.close()

    def get(self, endpoint, checksum="", json_data=True):
        checksum = self._get_checksum(checksum)
        cur_time = self._get_timestamp(datetime.datetime.now())
        result = None
        
        # 1. בדיקה בזיכרון המקומי (הכי מהיר)
        if self.enable_mem_cache and endpoint in self._mem_local_cache:
            expires, data, csum = self._mem_local_cache[endpoint]
            if expires > cur_time and (not checksum or checksum == csum):
                return data

        # 2. בדיקה ב-Window Property
        if self.enable_mem_cache:
            result = self._get_mem_cache(endpoint, checksum, cur_time, json_data)

        # 3. בדיקה ב-Database
        if result is None:
            result = self._get_db_cache(endpoint, checksum, cur_time, json_data)

        return result

    def set(self, endpoint, data, checksum="", expiration=datetime.timedelta(days=30), json_data=True):
        task_name = f"set.{endpoint}"
        self._busy_tasks.append(task_name)
        checksum = self._get_checksum(checksum)
        expires = self._get_timestamp(datetime.datetime.now() + expiration)

        # עדכון זיכרון מקומי
        if self.enable_mem_cache:
            self._mem_local_cache[endpoint] = (expires, data, checksum)
            self._set_mem_cache(endpoint, checksum, expires, data, json_data)

        # עדכון DB
        if not self._exit:
            self._set_db_cache(endpoint, checksum, expires, data, json_data)

        if task_name in self._busy_tasks:
            self._busy_tasks.remove(task_name)

    def _get_mem_cache(self, endpoint, checksum, cur_time, json_data):
        cachedata = self._win.getProperty(endpoint)
        if not cachedata:
            return None
        try:
            # שימוש ב-JSON במקום eval לביצועים ב-Python 3
            cachedata = json.loads(cachedata)
            if cachedata[0] > cur_time:
                if not checksum or checksum == cachedata[2]:
                    return cachedata[1]
        except Exception:
            return None
        return None

    def _set_mem_cache(self, endpoint, checksum, expires, data, json_data):
        cachedata = (expires, data, checksum)
        self._win.setProperty(endpoint, json.dumps(cachedata))

    def _get_database(self):
        '''מנהל חיבור יחיד ומהיר עם מצב WAL'''
        if self._db_connection:
            return self._db_connection

        addon = xbmcaddon.Addon(ADDON_ID)
        dbpath = addon.getAddonInfo('profile')
        dbfile = xbmcvfs.translatePath(f"{dbpath}/simplecache.db")

        if not xbmcvfs.exists(dbpath):
            xbmcvfs.mkdirs(dbpath)

        try:
            conn = sqlite3.connect(dbfile, timeout=30, isolation_level=None)
            # אופטימיזציה למהירות בקודי 21
            conn.execute('PRAGMA journal_mode = WAL')
            conn.execute('PRAGMA synchronous = NORMAL')
            conn.execute('CREATE TABLE IF NOT EXISTS simplecache(id TEXT UNIQUE, expires INTEGER, data TEXT, checksum INTEGER)')
            self._db_connection = conn
            return conn
        except Exception as e:
            self._log_msg(f"DB Error: {e}", xbmc.LOGWARNING)
            return None

    def _get_db_cache(self, endpoint, checksum, cur_time, json_data):
        db = self._get_database()
        if not db: return None
        
        query = "SELECT expires, data, checksum FROM simplecache WHERE id = ?"
        try:
            cursor = db.execute(query, (endpoint,))
            cache_data = cursor.fetchone()
            if cache_data and cache_data[0] > cur_time:
                if not checksum or cache_data[2] == checksum:
                    result = json.loads(cache_data[1])
                    if self.enable_mem_cache:
                        self._set_mem_cache(endpoint, checksum, cache_data[0], result, json_data)
                    return result
        except Exception:
            pass
        return None

    def _set_db_cache(self, endpoint, checksum, expires, data, json_data):
        db = self._get_database()
        if not db: return
        query = "INSERT OR REPLACE INTO simplecache(id, expires, data, checksum) VALUES (?, ?, ?, ?)"
        db.execute(query, (endpoint, expires, json.dumps(data), checksum))

    def check_cleanup(self):
        cur_time = datetime.datetime.now()
        lastexecuted = self._win.getProperty("simplecache.clean.lastexecuted")
        if not lastexecuted:
            self._win.setProperty("simplecache.clean.lastexecuted", str(time.time()))
        elif (float(lastexecuted) + self._auto_clean_interval.total_seconds()) < time.time():
            self._do_cleanup()

    def _do_cleanup(self):
        if self._exit or self._monitor.abortRequested(): return
        self._log_msg("Running optimized cleanup...")
        db = self._get_database()
        if not db: return
        
        cur_timestamp = self._get_timestamp(datetime.datetime.now())
        db.execute("DELETE FROM simplecache WHERE expires < ?", (cur_timestamp,))
        db.execute("VACUUM")
        self._win.setProperty("simplecache.clean.lastexecuted", str(time.time()))

    @staticmethod
    def _log_msg(msg, loglevel=xbmc.LOGDEBUG):
        xbmc.log(f"Skin Helper Simplecache --> {msg}", level=loglevel)

    @staticmethod
    def _get_timestamp(date_time):
        return int(time.mktime(date_time.timetuple()))

    def _get_checksum(self, stringinput):
        if not stringinput and not self.global_checksum:
            return 0
        stringinput = f"{self.global_checksum}-{stringinput}" if self.global_checksum else str(stringinput)
        return reduce(lambda x, y: x + y, map(ord, stringinput))

def use_cache(cache_hours=72):
    '''
    Decorator ממוצע ואופטימלי לקודי 21.
    ברירת מחדל: 72 שעות (3 ימים) - איזון מושלם בין רעננות נתונים למהירות.
    '''
    def decorator(func):
        def decorated(*args, **kwargs):
            method_class = args[0]
            method_class_name = method_class.__class__.__name__
            
            # יצירת מפתח מהיר בפורמט f-string (אופטימלי לפייתון 3)
            cache_str = f"{method_class_name}.{func.__name__}"
            for item in args[1:]:
                cache_str += f".{item}"
            cache_str = cache_str.lower()
            
            # בדיקה אם המשתמש ביקש ביטול סינון או התעלמות ממטמון
            global_cache_ignore = getattr(method_class, "ignore_cache", False)
            if kwargs.get("ignore_cache", False) or global_cache_ignore:
                result = func(*args, **kwargs)
                return result

            # ניסיון שליפה מהמטמון (משתמש ב-WAL mode למניעת לאגים)
            cachedata = method_class.cache.get(cache_str)

            if cachedata is not None:
                return cachedata
            
            # הרצת הפונקציה ושמירה עם תוקף ממוצע
            result = func(*args, **kwargs)
            # הגדרת תוקף בשעות לגמישות מקסימלית
            method_class.cache.set(cache_str, result, expiration=datetime.timedelta(hours=cache_hours))
            return result
            
        return decorated
    return decorator