#!/usr/bin/python
# -*- coding: utf-8 -*-

''' 
SimpleCache Turbo Edition - Optimized for Kodi 21+
No further improvements needed.
'''

import xbmcvfs
import xbmcgui
import xbmc
import xbmcaddon
import datetime
import time
import sqlite3
import json
import threading
from functools import reduce

ADDON_ID = "script.module.simplecache"

class SimpleCache(object):
    enable_mem_cache = True
    _auto_clean_interval = datetime.timedelta(hours=4)
    _db_connection = None
    _db_lock = threading.Lock() 

    def __init__(self):
        self._win = xbmcgui.Window(10000)
        self._mem_local_cache = {} 
        self.check_cleanup()
        self._log_msg("MAX PERFORMANCE MODE: ACTIVE")

    def _get_database(self):
        '''חיבור אופטימלי עם WAL ו-MMAP לביצועים מקסימליים'''
        with self._db_lock:
            if self._db_connection: return self._db_connection
            addon = xbmcaddon.Addon(ADDON_ID)
            dbpath = xbmcvfs.translatePath(addon.getAddonInfo('profile'))
            if not xbmcvfs.exists(dbpath): xbmcvfs.mkdirs(dbpath)
            dbfile = f"{dbpath}simplecache.db"
            try:
                conn = sqlite3.connect(dbfile, timeout=60, isolation_level=None)
                # אופטימיזציות מנוע ה-SQLite
                conn.execute('PRAGMA journal_mode = WAL')
                conn.execute('PRAGMA synchronous = NORMAL')
                conn.execute('PRAGMA mmap_size = 31457280') # 30MB Memory Mapping
                conn.execute('PRAGMA cache_size = -5000')   # 5MB Internal Page Cache
                conn.execute('CREATE TABLE IF NOT EXISTS simplecache(id TEXT UNIQUE, expires INTEGER, data TEXT, checksum INTEGER)')
                self._db_connection = conn
                return conn
            except: return None

    def get(self, endpoint, checksum="", json_data=True):
        '''שליפה רב-שכבתית אגרסיבית'''
        checksum = self._get_checksum(checksum)
        cur_time = self._get_timestamp(datetime.datetime.now())
        
        # 1. RAM Cache (L1)
        if self.enable_mem_cache and endpoint in self._mem_local_cache:
            expires, data, csum = self._mem_local_cache[endpoint]
            if expires > cur_time and (not checksum or checksum == csum):
                return data

        # 2. Window Property (L2)
        raw = self._win.getProperty(endpoint)
        if raw:
            try:
                expires, data, csum = json.loads(raw)
                if expires > cur_time and (not checksum or checksum == csum):
                    self._mem_local_cache[endpoint] = (expires, data, csum) # Promote to L1
                    return data
            except: pass

        # 3. Database (L3)
        db = self._get_database()
        if not db: return None
        try:
            cursor = db.execute("SELECT expires, data, checksum FROM simplecache WHERE id = ?", (endpoint,))
            row = cursor.fetchone()
            if row and row[0] > cur_time:
                if not checksum or row[2] == checksum:
                    data = json.loads(row[1])
                    # Update higher layers for next access
                    self._mem_local_cache[endpoint] = (row[0], data, row[2])
                    self._win.setProperty(endpoint, json.dumps((row[0], data, row[2])))
                    return data
        except: pass
        return None

    def set(self, endpoint, data, checksum="", expiration=datetime.timedelta(days=30)):
        '''שמירה אסינכרונית מלאה - אפס השפעה על ה-UI'''
        checksum = self._get_checksum(checksum)
        expires = self._get_timestamp(datetime.datetime.now() + expiration)

        # עדכון מיידי לשכבות המהירות (כדי שיהיה זמין בשנייה הבאה)
        self._mem_local_cache[endpoint] = (expires, data, checksum)
        self._win.setProperty(endpoint, json.dumps((expires, data, checksum)))

        # כתיבה לדיסק בשרשור רקע
        threading.Thread(target=self._async_db_set, args=(endpoint, checksum, expires, data), daemon=True).start()

    def prefetch(self, func, *args, **kwargs):
        '''טעינה מוקדמת חכמה - מריץ ושומר הכל בשקט'''
        threading.Thread(target=func, args=args, kwargs=kwargs, daemon=True).start()

    def _async_db_set(self, endpoint, checksum, expires, data):
        try:
            db = self._get_database()
            if db:
                db.execute("INSERT OR REPLACE INTO simplecache(id, expires, data, checksum) VALUES (?, ?, ?, ?)",
                           (endpoint, expires, json.dumps(data), checksum))
        except: pass

    def _get_checksum(self, stringinput):
        if not stringinput: return 0
        return reduce(lambda x, y: x + y, map(ord, str(stringinput)))

    def _get_timestamp(self, date_time):
        return int(time.mktime(date_time.timetuple()))

    def _log_msg(self, msg, level=xbmc.LOGDEBUG):
        xbmc.log(f"SimpleCache-Turbo -> {msg}", level)

    def check_cleanup(self):
        last = self._win.getProperty("simplecache.last_clean")
        if not last or (float(last) + self._auto_clean_interval.total_seconds() < time.time()):
            threading.Thread(target=self._do_cleanup, daemon=True).start()

    def _do_cleanup(self):
        db = self._get_database()
        if db:
            now = self._get_timestamp(datetime.datetime.now())
            db.execute("DELETE FROM simplecache WHERE expires < ?", (now,))
            db.execute("VACUUM") # דחיסת מסד הנתונים
            self._win.setProperty("simplecache.last_clean", str(time.time()))

# --- ה-Decorator שעוטף הכל בחבילה אחת ---

def use_cache(cache_hours=72):
    def decorator(func):
        def decorated(*args, **kwargs):
            obj = args[0]
            # יצירת מפתח ייחודי אוטומטי
            cls_name = obj.__name__ if hasattr(obj, '__name__') else obj.__class__.__name__
            cache_key = f"{cls_name}.{func.__name__}"
            for item in args[1:]:
                cache_key += f".{item}"
            
            if kwargs.get("ignore_cache") or getattr(obj, "ignore_cache", False):
                return func(*args, **kwargs)

            # שליפה מהירה
            res = obj.cache.get(cache_key)
            if res is not None: return res
            
            # הרצה ושמירה אוטומטית (Async)
            result = func(*args, **kwargs)
            obj.cache.set(cache_key, result, expiration=datetime.timedelta(hours=cache_hours))
            return result
        return decorated
    return decorator