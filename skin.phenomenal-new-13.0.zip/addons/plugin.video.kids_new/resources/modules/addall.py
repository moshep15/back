# -*- coding: utf-8 -*-
import sys,urllib,json,logging
import xbmcgui,xbmcplugin
def utf8_urlencode(params):
    import urllib as u
    # problem: u.urlencode(params.items()) is not unicode-safe. Must encode all params strings as utf8 first.
    # UTF-8 encodes all the keys and values in params dictionary
    for k,v in params.items():
        # TRY urllib.unquote_plus(artist.encode('utf-8')).decode('utf-8')
        if type(v) in (int, long, float):
            params[k] = v
        else:
            try:
                params[k.encode('utf-8')] = v.encode('utf-8')
            except Exception as e:
                logging.warning( '**ERROR utf8_urlencode ERROR** %s' % e )
    
    return u.urlencode(params.items()).decode('utf-8')
def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png",fan="DefaultFolder.png"):
 

          
           
          u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)

          liz.setInfo(type="Video", infoLabels={ "Title": urllib.unquote( name)   })
          liz.setProperty( "Fanart_Image", fan )
          liz.setProperty("IsPlayable","false")
          liz.setProperty( "Fanart_Image", iconimage )
          xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description,video_info={},generes=''):

        #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+urllib.quote_plus(description)
        params={}
        params['name']=name
        params['url']=url
        params['mode']=mode
        params['iconimage']=iconimage
        params['fanart']=fanart
        params['description']=description
        
        all_ur=utf8_urlencode(params)
        u=sys.argv[0]+"?mode="+str(mode)+'&'+all_ur
        
        ok=True
        menu_items=[]
        # menu_items.append(('[I]Clear Cache[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&mode=35')%(sys.argv[0])))
        liz=xbmcgui.ListItem(name, iconImage="DefaultFolder.png", thumbnailImage=iconimage)
        if video_info!={}:
                
            info=(video_info)
                
        else:
            info={ "Title": urllib.unquote( name), "Plot": description   }
        if generes!='':
            info['genre']=generes
        
        if mode==46:
            menu_items.append(('[I]הוספה למועדפים[/I]', 'XBMC.RunPlugin(%s?mode=7&name=%s&url=%s&iconimage=%s&fanart=%s&description=%s&video_info=%s)'  % ( sys.argv[0] ,name,url,iconimage,fanart,urllib.quote_plus(description.encode('utf8')),video_info)))
            menu_items.append(('[I]הסר מהמועדפים[/I]', 'XBMC.RunPlugin(%s?mode=9&name=%s&url=%s&iconimage=%s&fanart=%s&description=%s)'  % ( sys.argv[0] ,name,url,iconimage,fanart,description)))
            
        liz.setInfo( type="Video", infoLabels=info)
        liz.setProperty( "Fanart_Image", fanart )
        art = {}
        art.update({'poster': iconimage})
        liz.setArt(art)
        liz.addContextMenuItems(menu_items, replaceItems=False)
        #ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        return u,liz,True
        



def addLink( name, url,mode,isFolder, iconimage,fanart,description,data='',trailer=' ',video_info={},id=''):

          #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&id="+id+"&mode="+str(mode)+"&name="+(name)+"&data="+str(data)+"&iconimage="+urllib.quote_plus(iconimage)+"&fanart="+urllib.quote_plus(fanart)+"&description="+(description)
 

          
          params={}
          params['name']=name
          params['url']=url
          params['mode']=mode
          params['iconimage']=iconimage
          params['fanart']=fanart
          params['description']=description
          params['id']=id
          params['video_info']=(video_info)
          all_ur=utf8_urlencode(params)
          u=sys.argv[0]+"?mode="+str(mode)+'&'+all_ur
          menu_items=[]
          menu_items.append(('[I]Clear Cache[/I]', 'XBMC.RunPlugin(%s)' % ('%s?url=www&mode=35')%(sys.argv[0])))
          
          #u=sys.argv[0]+"?url="+urllib.quote_plus(url)+"&mode="+str(mode)+"&name="+urllib.quote_plus(name)
          liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)
          if video_info!={}:
                
                info=json.loads(video_info)
                info['trailer']=trailer
          else:
            info={ "Title": urllib.unquote( name), "Plot": description   }
          # if trailer!=' ':
          
          liz.setInfo(type="Video", infoLabels=info)
          art = {}
          art.update({'poster': iconimage})
          liz.setArt(art)
          liz.setProperty("IsPlayable","true")
          liz.setProperty( "Fanart_Image", iconimage )
          liz.addContextMenuItems(menu_items, replaceItems=False)
          #xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
          return u,liz,False