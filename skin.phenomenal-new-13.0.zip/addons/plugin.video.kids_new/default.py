# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,urllib2,re,xbmcplugin,sys,logging,json,time
from resources.modules import cache
__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__addon__ = xbmcaddon.Addon()
__cwd__ = xbmc.translatePath(__addon__.getAddonInfo('path')).decode("utf-8")
Addon = xbmcaddon.Addon()
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
try:
    from urllib.parse import quote_from_bytes as orig_quote
except ImportError:
    from urllib import quote as orig_quote
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
lang=xbmc.getLanguage(0)
addon_p=xbmc.translatePath("special://home/addons/plugin.video.wallmovie/db")
from resources.modules.addall import addLink,addDir3,addNolink
HEADERTYPE     = 'Image'
HEADERMESSAGE  = 'רשימת סרטים'
# url to image if using Image 424x180
PATH           = xbmcaddon.Addon().getAddonInfo('path')
ART            = os.path.join(PATH, 'resources', 'art')
HEADERIMAGE    = ''
HEADERIMAGE2    = ''

HEADERIMAGE3    = 'https://upload.wikimedia.org/wikipedia/commons/thumb/6/69/IMDB_Logo_2016.svg/1200px-IMDB_Logo_2016.svg.png'


ADDON_ID       = xbmcaddon.Addon().getAddonInfo('id')
BACKGROUND     = 'https://euimages.urbanoutfitters.com/is/image/UrbanOutfittersEU/5123433451032_001_s'
BACKGROUND2     = 'https://s.studiobinder.com/wp-content/uploads/2019/11/Marvel-Movies-in-Order-of-Story-Featured-StudioBinder-min.jpg'
BACKGROUND3     = 'https://s.studiobinder.com/wp-content/uploads/2019/11/Marvel-Movies-in-Order-of-Story-Featured-StudioBinder-min.jpg'
COLOR1         = 'gold'
COLOR2         = 'white'
COLOR3         = 'red'
COLOR3         = 'blue'
# Primary menu items   / %s is the menu item and is required
THEME1         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
# Alternate items      / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Current Build Header / %s is the menu item and is required 
THEME4         = '[COLOR '+COLOR1+']%s[/COLOR] [COLOR '+COLOR2+']גירסת בילד:[/COLOR]'
# Current Theme Header / %s is the menu item and is required
THEME5         = '[COLOR '+COLOR1+']Current Theme:[/COLOR] [COLOR '+COLOR2+']%s[/COLOR]'
ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
ACTION_MOVE_LEFT				=   1	## Left arrow key
ACTION_MOVE_RIGHT 				=   2	## Right arrow key
ACTION_MOVE_UP 					=   3	## Up arrow key
ACTION_MOVE_DOWN 				=   4	## Down arrow key
ACTION_MOUSE_WHEEL_UP 			= 104	## Mouse wheel up
ACTION_MOUSE_WHEEL_DOWN			= 105	## Mouse wheel down
ACTION_MOVE_MOUSE 				= 107	## Down arrow key
ACTION_SELECT_ITEM				=   7	## Number Pad Enter
ACTION_BACKSPACE				= 110	## ?
ACTION_MOUSE_LEFT_CLICK 		= 100
ACTION_MOUSE_LONG_CLICK 		= 108
def notification(msg='', test=False):
	class MyWindow(xbmcgui.WindowXMLDialog):
		def __init__(self, *args, **kwargs):
			self.test = kwargs['test']
			self.message =  THEME2 % kwargs['msg']
		
		def onInit(self):
			self.image       = 101
			self.image2       = 107
			self.titlebox    = 102
			self.titleimage  = 103
			self.titleimage2  = 109
			self.textbox     = 104
			self.scroller    = 105
			self.dismiss     = 201
			#self.remindme    = 202
			self.fastupdate  = 202
			self.showdialog()

		def showdialog(self):
			self.testimage = os.path.join(ART, 'text.png')
			self.getControl(self.image).setImage(BACKGROUND)
			self.getControl(self.image2).setImage(BACKGROUND2)
			self.getControl(self.image).setColorDiffuse('9FFFFFFF')
			self.getControl(self.textbox).setText(self.message)
			self.setFocusId(self.dismiss)
			# if HEADERTYPE == 'Text':
			self.getControl(self.titlebox).setLabel(THEME3 % HEADERMESSAGE)
			# else:
			self.getControl(self.titleimage).setImage(HEADERIMAGE)
			self.getControl(self.titleimage2).setImage(HEADERIMAGE2)
		def doFastupdate(self):


				self.close()

		def doRemindMeLater(self):

				self.close()

		def doDismiss(self):

				self.close()

		def onAction(self,action):
			if   action == ACTION_PREVIOUS_MENU: self.doRemindMeLater()
			elif action == ACTION_NAV_BACK: self.doRemindMeLater()

		def onClick(self, controlId):
			if (controlId == self.dismiss): self.doRemindMeLater()
			else: self.doFastupdate()
			
	xbmc.executebuiltin('Skin.SetString(headertexttype, %s)' % 'true' if HEADERTYPE == 'Text' else 'false')
	xbmc.executebuiltin('Skin.SetString(headerimagetype, %s)' % 'true' if HEADERTYPE == 'Image' else 'false')
	notify = MyWindow( "Notifications.xml" , Addon.getAddonInfo('path'), 'DefaultSkin', msg=msg, test=test)
	notify.doModal()
	del notify
    
    
    
def movielist():

    user_dataDir_pre = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    user_dataDir=os.path.join(user_dataDir_pre,'cache_f','anonymous')
    file= open(os.path.join(user_dataDir,'all_heb.txt'), 'r') 
    msg= file.read()
    file.close()
    notification(msg, True)
    sys.exit()
    
    
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     


def read_site_html(url_link):
    import requests
    '''
    req = urllib2.Request(url_link)
    req.add_header('User-agent',__USERAGENT__)# 'Mozilla/5.0 (Linux; U; Android 4.0.3; ko-kr; LG-L160L Build/IML74K) AppleWebkit/534.30 (KHTML, like Gecko) Version/4.0 Mobile Safari/534.30')
    html = urllib2.urlopen(req).read()
    '''
    html=requests.get(url_link)
    return html

def main_menu():
    purn=Addon.getSetting("purn")
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(addonPath, 'youtube.db')
    tmdb_cacheFilekids = os.path.join(addonPath, 'youtubekids.db')
    tmdb_cacheFileisrael = os.path.join(addonPath, 'youtubeisrael.db')
    tmdb_cacheFilesdarot = os.path.join(addonPath, 'youtubesdarot.db')
    tmdb_cacheFilepurn = os.path.join(addonPath, 'youtubepurn.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbconkids = database.connect(tmdb_cacheFilekids)
    dbconisrael = database.connect(tmdb_cacheFileisrael)
    dbconsdarot = database.connect(tmdb_cacheFilesdarot)
    dbconpurn = database.connect(tmdb_cacheFilepurn)
    dbcur = dbcon.cursor()
    dbcurkids = dbconkids.cursor()
    dbcurisrael = dbconisrael.cursor()
    dbcursdarot = dbconsdarot.cursor()
    dbcurpurn = dbconpurn.cursor()
    match=[('0')]
    match_tv=[('0')]
    match_israel=[('0')]
    match_sdarot=[('0')]
    try:
        dbcur.execute("SELECT * FROM updated where type='movies'")
        match = dbcur.fetchall()
        dbcurkids.execute("SELECT * FROM updated where type='movies'")
        match_tv = dbcurkids.fetchall()
        dbcurisrael.execute("SELECT * FROM updated where type='movies'")
        match_israel = dbcurisrael.fetchall()
        dbcursdarot.execute("SELECT * FROM updated where type='movies'")
        match_sdarot = dbcursdarot.fetchall()
        dbcurpurn.execute("SELECT * FROM updated where type='movies'")
        match_purn = dbcurpurn.fetchall()
        logging.warning(match)
        dbcur.execute("SELECT * FROM updated where type='tv'")
        # match_tv = dbcur.fetchall()
        logging.warning(match)
    except:
        pass
    if len(match)==0:
        match=[('0')]
    if len(match_tv)==0:
        match_tv=[('0')]
        
        
        
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'kids_movie')
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'newones')
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""origin TEXT);"% 'kids_show')
    
    dbcur.execute("SELECT * FROM kids_movie")
    
    
    
    
    
    dbcurkids.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'kids_movie')
    
    dbcurkids.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'newones')
    dbcurkids.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""origin TEXT);"% 'kids_show')
    
    dbcurkids.execute("SELECT * FROM kids_movie")
    
    
    
    dbcurisrael.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'kids_movie')
    
    dbcurisrael.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'newones')
    dbcurisrael.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""origin TEXT);"% 'kids_show')
    
    dbcurisrael.execute("SELECT * FROM kids_movie")
    
    

    dbcursdarot.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'kids_movie')
    
    dbcursdarot.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'newones')
    dbcursdarot.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""origin TEXT);"% 'kids_show')
    
    dbcursdarot.execute("SELECT * FROM kids_movie")


    dbcurpurn.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'kids_movie')
    
    dbcurpurn.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'newones')
    dbcurpurn.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""origin TEXT);"% 'kids_show')
    
    dbcurpurn.execute("SELECT * FROM kids_movie")

    match2 = dbcur.fetchall()
    match3 = dbcurkids.fetchall()
    match4 = dbcurisrael.fetchall()
    match5 = dbcursdarot.fetchall()
    match6 = dbcurpurn.fetchall()
    all_names=[]
    count_m=0
    for name1,link,con1,origin,icon,image,plot,data in match2:
        if name1 not in all_names:
            all_names.append(name1)
            count_m+=1
    dbcur.execute("SELECT * FROM kids_show ")
    dbcurkids.execute("SELECT * FROM kids_show ")
    match2 = dbcur.fetchall()
    
    
    all_names=[]
    count_tv=0
    count_israel=0
    count_sdarot=0
    count_purn=0
    for name1,link,con1,origin,icon,image,plot,data in match3:
        if name1 not in all_names:
            all_names.append(name1)
            count_tv+=1
            

    for name1,link,con1,origin,icon,image,plot,data in match4:
        if name1 not in all_names:
            all_names.append(name1)
            count_israel+=1
            
    for name1,link,con1,origin,icon,image,plot,data in match5:
        if name1 not in all_names:
            all_names.append(name1)
            count_sdarot+=1
            
    for name1,link,con1,origin,icon,image,plot,data in match6:
        if name1 not in all_names:
            all_names.append(name1)
            count_purn+=1
            
    all_d=[]
    # all_d.append(addDir3('סרטים (%s) '%str(count_m),'0',1,'https://watchmoviesreview.files.wordpress.com/2020/02/may_2020_comingsoon.jpg?w=1024','https://watchmoviesreview.files.wordpress.com/2020/02/may_2020_comingsoon.jpg?w=1024','סרטים',generes=match[0][0]))
    
    # all_d.append(addDir3('סרטים ישראלים (%s) '%str(count_israel),'0',17,'https://img.freepik.com/vector-gratis/bandera-israel-hecha-pintura-brillante-sparkle-brush_1379-2132.jpg?size=626&ext=jpg','https://img.freepik.com/vector-gratis/bandera-israel-hecha-pintura-brillante-sparkle-brush_1379-2132.jpg?size=626&ext=jpg','סרטים ישראלים',generes=match_tv[0][0]))
    
    all_d.append(addDir3('סרטים מדובבים (%s) '%str(count_tv),'0',13,'https://media.timeout.com/images/105586169/image.jpg','https://media.timeout.com/images/105586169/image.jpg','סרטים מדובבים',generes=match_tv[0][0]))
    
    # all_d.append(aa)
    all_d.append(addDir3('סדרות לילדים','www',2,'https://travelmamas.com/wp-content/uploads/2017/10/best_travel_movies_for_kids_frozen-837x1200.jpg','https://www.slashfilm.com/wp/wp-content/images/Astro-Boy.jpg','ילדים',generes=match_tv[0][0]))
    # all_d.append(addDir3('סדרות לילדים טלמדיה (%s) '%str(count_sdarot),'www',21,'https://travelmamas.com/wp-content/uploads/2017/10/best_travel_movies_for_kids_frozen-837x1200.jpg','https://www.slashfilm.com/wp/wp-content/images/Astro-Boy.jpg','ילדים',generes=match_tv[0][0]))
    # if purn == 'true':
    # all_d.append(addDir3('סרטים למבוגרים (%s) '%str(count_purn),'0',19,'https://cdn.eslgaming.com/play/eslgfx/gfx/logos/playerphotos/11683000/11683809_big.jpg','https://cdn.eslgaming.com/play/eslgfx/gfx/logos/playerphotos/11683000/11683809_big.jpg','סרטים למבוגרים',generes=match_tv[0][0]))
    # all_d.append(addDir3('ערוצים מהעולם','www',48,'https://upload.wikimedia.org/wikipedia/en/7/76/Channels_TV.jpg','http://smart-living-technology.com/wp-content/uploads/2018/07/HD-Antenna-Channels-modal_03.jpg','Live',generes=match_tv[0][0]))
    # addDir3('[COLOR orange][I]ערוצים מהעולם[/I][/COLOR]'.decode('utf8'),'www',143,'https://upload.wikimedia.org/wikipedia/en/7/76/Channels_TV.jpg','http://smart-living-technology.com/wp-content/uploads/2018/07/HD-Antenna-Channels-modal_03.jpg','Live'.decode('utf8'))
    # all_d.append(addDir3('קדימונים לילדים','www',4,'https://imagesvc.timeincapp.com/v3/mm/image?url=https%3A%2F%2Fewedit.files.wordpress.com%2F2017%2F11%2Fanimationsplit.jpg%3Fw%3D2000&w=700&q=85','https://cdn1.thr.com/sites/default/files/imagecache/list_landscape_960x541/2017/08/coco_ferdinand_the_star_lego_ninjago_my_little_pony_-_split_-_publicity_-_h_2017_1.jpg','טרליירים'))
    
    # all_d.append(addDir3('סדרות מועדפות','www',48,'https://www.netclipart.com/pp/m/186-1868147_kids-logo-tv-show-logos-childrens-logo-church.png','https://www.denofgeek.com/wp-content/uploads/2020/03/UK-Kids-streaming.jpg?fit=1200%2C675','סדרות מועדפות'))

    # all_d.append(addDir3('הצג רשימת סרטים','www',14,'https://d3v4jsc54141g1.cloudfront.net/uploads/project/avatar/35612/large_cover_kiss_kiss-1413361078.jpg','https://d3v4jsc54141g1.cloudfront.net/uploads/project/avatar/35612/large_cover_kiss_kiss-1413361078.jpg','הצג רשימת סרטים'))
    # all_d.append(addDir3('המשך צפייה','www',12,'https://upload.wikimedia.org/wikipedia/commons/3/35/1_Monet_Play_logo.png','https://upload.wikimedia.org/wikipedia/commons/3/35/1_Monet_Play_logo.png','סדרות מועדפות'))
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%'last_played_movie' )
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%'last_played_tv' )
   
    dbcur.execute("SELECT * FROM last_played_movie")
    match = dbcur.fetchall()
    # for name ,url ,video_info ,id ,icon ,fan ,free in match:
        # all_d.append(addLink(name.replace('%27',"'"),url,5,False,icon,fan,free.replace('%27',"'"),video_info=urllib.unquote_plus(video_info),id=id))
    # dbcur.execute("SELECT * FROM last_played_tv")
    # match = dbcur.fetchall()
    # for name ,url ,video_info ,id ,icon ,fan ,free in match:
        # all_d.append(addLink(name.replace('%27',"'"),url,5,False,icon,fan,free.replace('%27',"'"),video_info=urllib.unquote_plus(video_info),id=id))
    all_d.append(addDir3('חיפוש','search',11,'https://lh5.googleusercontent.com/proxy/-RGejAHqTw0SEl8o3_eK3abBTFCoR49bh780mJ-HX2kK_Qf0aeTzeKuN_WHmW5wOZzKEmlsHE684lxp8BNbejnLx-S4S7dJDeCea3ESPCPMrkUucyFXNH5F_4iktdqh7vKfE5QNGtMZF6QAwAGknYp6v8oeRQg','https://searchengineland.com/figz/wp-content/seloads/2017/12/compare-seo-ss-1920-800x450.jpg','search'))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    addNolink( '[COLOR yellow]עדכן מאגר[/COLOR]', 'www',15,False, iconimage="https://www.kindpng.com/picc/m/189-1893945_transparent-important-update-hd-png-download.png",fan='https://ewscripps.brightspotcdn.com/dims4/default/a4ce516/2147483647/strip/true/crop/1280x720+0+0/resize/1280x720!/quality/90/?url=http%3A%2F%2Fewscripps-brightspot.s3.amazonaws.com%2F81%2F97%2F5b1a44e34c148c047cf968f93107%2Fsummer-movies-2020.jpg')
    addNolink( '[COLOR red]נקה מאגר[/COLOR]', 'www',35,False, iconimage="https://www.wallpaperup.com/uploads/wallpapers/2016/02/22/898029/91ed2d4c91151c06cb9b09a83b23440b-700.jpg",fan='https://ewscripps.brightspotcdn.com/dims4/default/a4ce516/2147483647/strip/true/crop/1280x720+0+0/resize/1280x720!/quality/90/?url=http%3A%2F%2Fewscripps-brightspot.s3.amazonaws.com%2F81%2F97%2F5b1a44e34c148c047cf968f93107%2Fsummer-movies-2020.jpg')
    dbcur.close()
    dbcon.close()
    
def ClearCache():
  
    # logging.warning('Clear')
    # cache.clear(['cookies', 'pages','posters'])
    # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kids', 'Cleared')))
   addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
   addon_p=xbmc . translatePath ( os . path . join ( 'special://home/userdata/addon_data' , 'plugin.video.telemedia' ) )
   

   # tmdb_cacheFile = os.path.join(addonPath, 'youtubekids.db')
   # tmdb_cacheFile2 = os.path.join(addonPath, 'telehebdubkids.db')
   tmdb_cacheFile3 = os.path.join(addonPath, 'youtube.db')
   tmdb_cacheFile4 = os.path.join(addonPath, 'telehebdub.db')

   # try:
        # os.remove(os.path.join(addon_p, tmdb_cacheFile))
   # except:pass
   # try:
        # os.remove(os.path.join(addon_p, tmdb_cacheFile2))
   # except:pass
   try:
        os.remove(os.path.join(addon_p, tmdb_cacheFile3))
   except:pass
   try:
        os.remove(os.path.join(addon_p, tmdb_cacheFile4))
   except:pass
   xbmc.executebuiltin('Container.Refresh')
   LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]המאגר נוקה[/COLOR]' % COLOR2)
   # sys.exit()
   # os._exit(1)
def get_sdarot(url):
       from sdarot import MyResolver
       url_data=json.loads(url)
       logging.warning('Doner Test Resolve:')
       url, cookie=get_final_video_and_cookie(url_data[0], url_data[1], url_data[2], False, False)
       '''
       regex='https://(.+?)/'
       match=re.compile(regex).findall(url)
       h=(MyResolver(match[0]))
       url=url.replace(match[0],h)
       '''
       return url
def get_final_video_and_cookie(sid, season, episode, choose_quality=False, download=False):
    from resources.modules.sdarot import get_sdarot_ck,get_sdarot_ck,get_video_url
    local=False
    #get_sdarot_ck(sid,season,episode)
    token,cookie=cache.get(get_sdarot_ck,3,sid,season,episode, table='cookies')
    logging.warning('sd cookie')
    logging.warning(cookie)
   
    logging.warning('sd cookie2')
    logging.warning('Doner Test:'+token)
    logging.warning(cookie)
    #cookie={'Sdarot':'FOcYpGHLb'}
    if cookie=={} or token == 'donor':
        logging.warning('Get donor')
        token,cookie=cache.get(get_sdarot_ck,0,sid,season,episode,cookie, table='cookies')
        logging.warning('Doner Test22:'+token)
        logging.warning(cookie)
    else:
        vid = get_video_url(sid, season, episode, token, cookie, choose_quality)
        logging.warning('sd vid')
        logging.warning(vid)
        if 'errors' not in vid:
             return vid, cookie
        else:
            xbmc.executebuiltin((u'Notification(%s,%s)' % ('Victory', vid['errors'][0])).encode('utf-8'))
            
        if 'uid=|Co' in vid:
           
            token,cookie=cache.get(get_sdarot_ck,0,sid,season,episode, table='cookies')
          
        else:
           
 
           
           if 'errors' not in vid:
             return vid, cookie
    logging.warning(token)
    if token == 'donor':
        vid = get_video_url(sid, season, episode, token, cookie, choose_quality)

    else:
        if download:
            #plugin.notify('התחבר כמנוי כדי להוריד פרק זה', image=ICON)
            return None, None
        else:
            vid = get_video_url(sid, season, episode, token, cookie, choose_quality)
            if 'errors' in vid:
                msg="אנא המתן 30 שניות"#vid['errors'][0]
            else:
                msg="אנא המתן 30 שניות"
            if not local:
                
                dp = xbmcgui.DialogProgress()
                dp.create("לצפייה באיכות HD וללא המתנה ניתן לרכוש מנוי", msg, vid['errors'][0],
                          "[COLOR orange][B]לרכישת מנוי להיכנס בדפדפן - www.sdarot.tv/donate[/B][/COLOR]")
                dp.update(0)
            tm=31
   
            if not 'errors' in vid:
             tm=0
         
             return vid, cookie
            else:
                
                tm=re.findall(r' \d+ ', vid['errors'][0])
                if len(tm)==0:
                    
                        xbmcgui.Dialog().ok('Sdaror TV',vid['errors'][0])
                        sys.exit()
                tm=int (tm[0].strip())
                if tm>28:
                    token,cookie=cache.get(get_sdarot_ck,0,sid,season,episode, table='cookies')
                    tm=30
            
            
            
            

            for s in range(tm, -1, -1):
                time.sleep(1)
                if  local:
                    sys.stdout.write("\r עוד {0} שניות".format(s))
                    sys.stdout.flush()
                else:
                    dp.update(int((tm - s) / (tm+1) * 100.0), msg, 'עוד {0} שניות'.format(s), '')
                    if dp.iscanceled():
                        dp.close()
                        return None, None
        

        
        vid = get_video_url(sid, season, episode, token, cookie, choose_quality)
        logging.warning('VID LINK')
        
        if 'errors' in vid:
                    xbmcgui.Dialog().ok('Sdaror TV',vid['errors'][0])
                    sys.exit()
    if vid:
           
            return vid, cookie
def getParams(arg):
	param=[]
	paramstring=arg
	if len(paramstring)>=2:
		params=arg
		cleanedparams=params.replace('?','')
		if (params[len(params)-1]=='/'):
			params=params[0:len(params)-2]
		pairsofparams=cleanedparams.split('&')
		param={}
		for i in range(len(pairsofparams)):
			splitparams={}
			splitparams=pairsofparams[i].split('=')
			if (len(splitparams))==2:    
				param[splitparams[0]]=splitparams[1]
							
	return param

def getParam(name,params):
	try:
		return urllib.unquote_plus(params[name])
	except:
		pass
wall=None
action=None
if len(sys.argv) >= 2:   
	params = getParams(sys.argv[2])
	wall=getParam("wall", params)
	action=getParam("action", params)
def resolve_link(url,id,plot,icon,name1,fan,year,tmdb):
    imdbx = getParam("imdb",params)
    traktx = getParam("trakt",params)
    yearx = getParam("year",params)
    namex = (xbmc.getInfoLabel("ListItem.title"))
    titlex = getParam("title",params)
    urlx = getParam("url",params)
    slugx = (xbmc.getInfoLabel("ListItem.Plot"))
    thumbx = (xbmc.getInfoLabel("ListItem.Art(thumb)"))
    fanartx = (xbmc.getInfoLabel("ListItem.Art(fanart)"))
    logging.warning(params)
    directPlay = Addon.getSetting("DirectPlay")
    import requests
    streamAddonMV = Addon.getSetting("StreamMovies")
    choiseplay = Addon.getSetting("choiseplay")
    
    
    
    
    tv_movie='movie'
    lang='en'
    
    
    
    
    url3='https://api.themoviedb.org/3/%s/%s?api_key=34142515d9d23817496eeb4ff1d223d0&language=%s&include_image_language=ru,null&append_to_response=images'%(tv_movie,id,lang)
    try:
     original_title=requests.get(url3).json()['title']
    except:original_title=name1
    
    
    url2='http://api.themoviedb.org/3/movie/%s?api_key=%s&language=he&append_to_response=external_ids'%(id,'653bb8af90162bd98fc7ee32bcbbfb3d')
    
    try:
     imdb_id=requests.get(url2).json()['external_ids']['imdb_id']
    except:imdb_id=id
    # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous', year)))
    # sys.exit()
    if 'tv4kids' in url:
        url=urllib.unquote_plus(url).replace('[[OS]]','')
        logging.warning('f_url:'+url.replace('[[OS]]','').decode('utf8'))
        headers = {
            'authority': 'tv4kids.tk',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'sec-fetch-site': 'none',
            'sec-fetch-mode': 'navigate',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            
        }

        response = requests.get(url, headers=headers,stream=True).url
        


        headers = {
            'authority': 'tv4kids.tk',
            'accept-encoding': 'identity;q=1, *;q=0',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'accept': '*/*',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'no-cors',
            'referer':url.replace('[[OS]]',''),
            'accept-language': 'en-US,en;q=0.9',
           
        }
        
        head=urllib.urlencode(headers)
        url=url+"|"+head
        url=response
        
    if 'drive.google.com' in url:
        from resources.modules.google_solve import googledrive_resolve
        regex='\[\[(.+?)\]\]'
        match2=re.compile(regex).findall(url)
        if len(match2)>0:
           
            url=url.replace(match2[0],'').replace('[','').replace(']','').strip()
        
        url,q=googledrive_resolve(url)
    if '%%%' in url:
        regex='\[\[(.+?)\]\]'
        match2=re.compile(regex).findall(url)
        if len(match2)>0:
           
            url=url.replace(match2[0],'').replace('[','').replace(']','').strip()
        url=url.split('%%%')[0]
        url_id=url
        # logging.warning(fan,'xxxxx')
        if (streamAddonMV=="כל הנגנים"):
        

        
        
                list_players = ['Telemedia', 'Mando', 'Torrent', 'Exodusredux', 'TheCrew']
                # list_players=['Telemedia','mando']
                selection = xbmcgui.Dialog().select("נגן דרך", list_players)
                # ret = xbmcgui.Dialog().select("נגן דרך", list_players
                if selection == -1:
                    sys.exit()
                plugin = list_players[selection]
                
                
                
                
                if plugin=='Mando':
                   url='plugin://plugin.video.mando/?mode=15&title={0}&description={1}&imdb={2}&season=%20&episode=%20&tvdb= &data={3}&eng_name={4}&fanart=%20&iconimage=%20&heb_name={5}&name={6}&original_title={7}&show_original_year={8}&id={9}&url=www&fanart={10}&iconimage={11}'.format(original_title,plot,imdb_id,year,original_title,name,name,original_title,year,imdb_id,icon,icon)
                elif plugin=='Telemedia':
                   
                    url='plugin://plugin.video.telemedia/?url=%s&no_subs=%s&season=%s&episode=%s&mode=15&original_title=%s&id=%s&data=&fanart=%s&url=%s&iconimage=%s&file_name=%s&description=%s&resume=%s&name=%s&heb_name=%s'%(url_id,'1','%20','%20',name1.decode('utf-8','ignore').encode("utf-8"),imdb_id,icon,name1.decode('utf-8','ignore').encode("utf-8"),icon,'',plot,'',name1,name1)
                    
                elif plugin=='Torrent':
                    url='plugin://plugin.video.torrent/?mode=4&title={0}&description={1}&imdb={2}&season=%20&episode=%20&tvdb= &data={3}&eng_name={4}&fanart=%20&iconimage=%20&heb_name={5}&name={6}&original_title={7}&show_original_year={8}&id={9}&url=www&fanart={10}&iconimage={11}&fav_status=false'.format(original_title,plot,imdb_id,year,name,name1,name1,original_title,year,imdb_id,icon,icon)
                
                
                elif plugin=='Exodusredux':
                    url='plugin://plugin.video.exodusredux/?action=play&imdb={0}&meta={1}&year={2}&title={3}'.format(imdb_id,urllib.quote('{"thumb":"%s","code": "%s","originaltitle": "%s"}' % (xbmc.getInfoLabel("ListItem.Art(thumb)"),imdb_id,original_title),safe=''),year,original_title.replace(' ','%20'))
                    
                    
                    
                    
                elif plugin=='TheCrew':
                    url='plugin://plugin.video.thecrew/?action=play&imdb={0}&meta={1}&year={2}&title={3}'.format(imdb_id,urllib.quote('{"thumb":"%s","code": "%s","originaltitle": "%s"}' % (xbmc.getInfoLabel("ListItem.Art(thumb)"),imdb_id,original_title),safe=''),year,original_title.replace(' ','%20'))
                
                
                
                
                
                
                
                
                
        # else:
        
        if (streamAddonMV=="Telemedia"):
            url='plugin://plugin.video.telemedia/?url=%s&no_subs=%s&season=%s&episode=%s&mode=15&original_title=%s&id=%s&data=&fanart=%s&url=%s&iconimage=%s&file_name=%s&description=%s&resume=%s&name=%s&heb_name=%s'%(url_id,'1','%20','%20',name1.decode('utf-8','ignore').encode("utf-8"),imdb_id,icon,name1.decode('utf-8','ignore').encode("utf-8"),icon,'',plot,'',name1,name1)
        if (streamAddonMV=="Mando"):
            url='plugin://plugin.video.mando/?mode=15&title={0}&description={1}&imdb={2}&season=%20&episode=%20&tvdb= &data={3}&eng_name={4}&fanart=%20&iconimage=%20&heb_name={5}&name={6}&original_title={7}&show_original_year={8}&id={9}&url=www&fanart={10}&iconimage={11}'.format(original_title,plot,imdb_id,year,original_title,name,name,original_title,year,imdb_id,icon,icon)
            # url=('plugin://plugin.video.metalliq/movies/play/imdb/%s/library'%(imdb_id))
        if (streamAddonMV=="Torrent"):
            url='plugin://plugin.video.torrent/?mode=4&title={0}&description={1}&imdb={2}&season=%20&episode=%20&tvdb= &data={3}&eng_name={4}&fanart=%20&iconimage=%20&heb_name={5}&name={6}&original_title={7}&show_original_year={8}&id={9}&url=www&fanart={10}&iconimage={11}&fav_status=false'.format(original_title,plot,imdb_id,year,name,name1,name1,original_title,year,imdb_id,icon,icon)
            
            
        if (streamAddonMV=="exodusredux"):
            url='plugin://plugin.video.exodusredux/?action=play&imdb={0}&meta={1}&year={2}&title={3}'.format(imdb_id,urllib.quote('{"thumb":"%s","code": "%s","originaltitle": "%s"}' % (xbmc.getInfoLabel("ListItem.Art(thumb)"),imdb_id,original_title),safe=''),year,original_title.replace(' ','%20'))
            
            
            
            
        if (streamAddonMV=="TheCrew"):
            url='plugin://plugin.video.thecrew/?action=play&imdb={0}&meta={1}&year={2}&title={3}'.format(imdb_id,urllib.quote('{"thumb":"%s","code": "%s","originaltitle": "%s"}' % (xbmc.getInfoLabel("ListItem.Art(thumb)"),imdb_id,original_title),safe=''),year,original_title.replace(' ','%20'))
            # url='plugin://plugin.video.telemedia/?url=%s&no_subs=%s&season=%s&episode=%s&mode=15&original_title=%s&id=%s&data=&fanart=&url=%s&iconimage=&file_name=%s&description=%s&resume=%s&name=%s&heb_name=%s'%(url_id,'1','%20','%20',name1.decode('utf-8','ignore').encode("utf-8"),id,url_id,name1.decode('utf-8','ignore').encode("utf-8"),plot,'',name1,name1)

        # logging.warning(fan,'xxxxx')
    if '[' in url and 'http' not in url:
       from resources.modules.sdarot import MyResolver
       url_data=json.loads(url)
       logging.warning('Doner Test Resolve:')
       url, cookie=get_final_video_and_cookie(url_data[0], url_data[1], url_data[2], False, False)
    if 'f2h' in url:
        url=url.replace('nana10.co.il','io')
        headers = {
        'Pragma': 'no-cache',
        
        'Accept-Encoding': 'utf8',

        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',


        
        }
        html=requests.get(url,headers=headers).content
        
        regex='<script.+?"(.+?)/ip.php'
        match=re.compile(regex).findall(html)

        for links in match:
         
         if 'f2h.co.il' in links:
           id=links

        regex2="<form name='myform' id='myform' method='post' action='.+?/thanks/(.+?)'"
        match2=re.compile(regex2).findall(html)

        url=id+'/files/'+match2[0].replace("|","%7C")
    if 'www.youtube.com' in url :
        vid=re.compile('\?(?:v|id)=(.+?)(?:$|&)').findall(url)[0]
        url='plugin://plugin.video.youtube/play/?video_id='+vid
    return url
    
def play_trailer(id):
    import requests
    tv_movie='movie'
    
    # xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kodi Anonymous',id)))
    logging.warning('wallmovie Trailer')
    if tv_movie=='movie':
        url_t='http://api.themoviedb.org/3/movie/%s/videos?api_key=1248868d7003f60f2386595db98455ef'%id
        html_t=requests.get(url_t).json()
        if 'results' in html_t:
            try:
             video_id=(html_t['results'][0]['key'])
            except:
                LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אין טריילר[/COLOR]' % COLOR2)
                sys.exit()
        else:
            LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]אין טריילר[/COLOR]' % COLOR2)
            sys.exit()
    else:
        url_t='http://api.themoviedb.org/3/tv/%s/videos?api_key=1248868d7003f60f2386595db98455ef'%id
        html_t=requests.get(url_t).json()
        video_id=(html_t['results'][0]['key'])
    from resources.modules.youtube_ext import get_youtube_link2
    # from youtube_ext import get_youtube_link2
    playback_url=''
    if video_id!=None:
      try:
       
        playback_url= get_youtube_link2('https://www.youtube.com/watch?v='+video_id).replace(' ','%20')
        
    
      except Exception as e:
            logging.warning('Error playing youtube:'+str(e))
            pass
      #from pytube import YouTube
      #playback_url = YouTube(domain_s+'www.youtube.com/watch?v='+video_id).streams.first().download()
         
       
        
      #playback_url = 'plugin://plugin.video.youtube/?action=play_video&videoid=%s' % video_id
      item = xbmcgui.ListItem(path=playback_url)
      xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, item)
def resolve_linkkids(url,id,plot,icon,name1,fan):
    import requests
    if 'tv4kids' in url:
        url=urllib.unquote_plus(url).replace('[[OS]]','')
        logging.warning('f_url:'+url.replace('[[OS]]','').decode('utf8'))
        headers = {
            'authority': 'tv4kids.tk',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'sec-fetch-site': 'none',
            'sec-fetch-mode': 'navigate',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            
        }

        response = requests.get(url, headers=headers,stream=True).url
        


        headers = {
            'authority': 'tv4kids.tk',
            'accept-encoding': 'identity;q=1, *;q=0',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'accept': '*/*',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'no-cors',
            'referer':url.replace('[[OS]]',''),
            'accept-language': 'en-US,en;q=0.9',
           
        }
        
        head=urllib.urlencode(headers)
        url=url+"|"+head
        url=response
        
    if 'drive.google.com' in url:
        from resources.modules.google_solve import googledrive_resolve
        regex='\[\[(.+?)\]\]'
        match2=re.compile(regex).findall(url)
        if len(match2)>0:
           
            url=url.replace(match2[0],'').replace('[','').replace(']','').strip()
        
        url,q=googledrive_resolve(url)
    if '%%%' in url:
        regex='\[\[(.+?)\]\]'
        match2=re.compile(regex).findall(url)
        if len(match2)>0:
           
            url=url.replace(match2[0],'').replace('[','').replace(']','').strip()
        url=url.split('%%%')[0]
        url_id=url
        url='plugin://plugin.video.telemedia/?url=%s&no_subs=%s&season=%s&episode=%s&mode=40&original_title=%s&id=%s&data=&fanart=&url=%s&iconimage=&file_name=%s&description=%s&resume=%s&name=%s&heb_name=%s'%(url_id,'1','%20','%20',name1.decode('utf-8','ignore').encode("utf-8"),id,url_id,name1.decode('utf-8','ignore').encode("utf-8"),plot,'',name1,name1)
        logging.warning(url)
    if '[' in url and 'http' not in url:
       from resources.modules.sdarot import MyResolver
       url_data=json.loads(url)
       logging.warning('Doner Test Resolve:')
       url, cookie=get_final_video_and_cookie(url_data[0], url_data[1], url_data[2], False, False)
    if 'f2h' in url:
        url=url.replace('nana10.co.il','io')
        headers = {
        'Pragma': 'no-cache',
        
        'Accept-Encoding': 'utf8',

        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',


        
        }
        html=requests.get(url,headers=headers).content
        
        regex='<script.+?"(.+?)/ip.php'
        match=re.compile(regex).findall(html)

        for links in match:
         
         if 'f2h.co.il' in links:
           id=links

        regex2="<form name='myform' id='myform' method='post' action='.+?/thanks/(.+?)'"
        match2=re.compile(regex2).findall(html)

        url=id+'/files/'+match2[0].replace("|","%7C")
    if 'www.youtube.com' in url :
        vid=re.compile('\?(?:v|id)=(.+?)(?:$|&)').findall(url)[0]
        url='plugin://plugin.video.youtube/play/?video_id='+vid
    return url
def play_link(name,url,video_info,id,icon,fan,plot,year):
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(addonPath, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    if 'tv_title' in video_info:
        table_name='last_played_tv'
    else:
        table_name='last_played_movie'
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%table_name )
    dbcur.execute("DELETE FROM "+table_name)
    # dbcur.execute("INSERT INTO %s Values ('%s','%s','%s','%s','%s','%s','%s')"%(table_name,name.replace("'","%27"),url,urllib.quote_plus(video_info),id,icon,fan,plot.replace("'","%27")))
    
    dbcon.commit()
    dbcur.close()
    dbcon.close()

    all_data=json.loads(video_info)
    all_f_name=[]
    if '$$$' in url:
       links=url.split('$$$')
       sour_pre=''
       sour=''
       all_s=[]
       for lk in links:
           f_name=''
           regex='\[\[(.+?)\]\]'
           match=re.compile(regex).findall(str(lk))
           if len(match)==0:
               if 'TEME' in lk:
                 ff_link=lk
                 f_name=lk.split('%%%')[1].split('_')[1]
                 
                 # ff_link=fn.replace(match2[0],'').replace('[','').replace(']','')
                 match=[('TE',f_name)]
               else:
                    regex='//(.+?)/'
                     
                    match_ser=re.compile(regex).findall(str(lk))
            
                    if len(match_ser)>0:
                         match=[]
                         match.append((sour,match_ser[0]))
                    else:
                        match=[]
                        match.append((sour,'Direct'))
           else:
                if 'TEME' in lk:
                 logging.warning(lk)
                 ff_link=lk
                 f_name=lk.split('%%%')[1].split('_')[1]
                 
                 match=[('',f_name)]
                 
                else:
                    regex='\[\[(.+?)\]\].+?//(.+?)/'
                    match=re.compile(regex).findall(str(lk))
                if len(match)==0:
                    if 'TEME' in lk:
                     ff_link=lk
                     f_name=lk.split('%%%')[1].split('_')[1]
                     
                     match=[('',f_name)]
                     
                    else:
                        regex='\[\[(.+?)\]\]'
                        sour=re.compile(regex).findall(str(lk))[0]
                        match=[]
                        match.append((sour,'Direct'))
           
           for sour,ty in match:
                all_f_name.append(f_name)
                sour=sour.replace('openload','vummo')
                ty=ty.replace('tv4kids','streamango').replace('.tk','.com')
                if 'sratim' in ty:
                    ty='str'
                all_s.append('[COLOR lightblue][B]'+sour+'[/B][/COLOR]  [COLOR white]'+ty.replace('letsupload','avlts')+'[/COLOR]')
                
       #logging.warning(all_s)
       
       # ret = xbmcgui.Dialog().select("בחר", all_s)
       # if ret!=-1:
         # #logging.warning(links)
         # #logging.warning(ret)
         # ff_link=links[ret]
         
         # regex='\[\[(.+?)\]\]'
         # match2=re.compile(regex).findall(links[ret])
         # if len(match2)>0:
           # if 'TE' in all_s[ret]:
            
            
            # ff_link=ff_link
            # logging.warning('ff_link2:'+ff_link)
           # if 'http' in ff_link or 'TE' in all_s[ret]:
            # ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
           # else:
            # ff_link=ff_link.replace(match2[0],'')
         # else:
            # try:
                # if 'http' in ff_link:
                    # ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
                # else:
                    # ff_link=ff_link.replace(match2[0],'')
            # except:
                # pass
         # logging.warning('ff_link:'+ff_link)
        
         # if 'TE' in all_s[ret]:
            
            
            # heb_name=all_f_name[ret]
            # saved_name=all_f_name[ret]
            # original_title=all_f_name[ret]
            # season='%20'
            
         # url=ff_link.strip()
       # else:
         # sys.exit()
    
    url=resolve_link(url,id,all_data['plot'],icon,name,fan,all_data['year'],all_data['tmdb'])
    listItem = xbmcgui.ListItem(all_data['title'], path=url) 
    listItem.setInfo(type='Video', infoLabels=all_data)


    listItem.setProperty('IsPlayable', 'true')
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
def unpad(padded_data, block_size, style='pkcs7'):
    pdata_len = len(padded_data)
    if style in ('pkcs7', 'x923'):
        padding_len = ord(padded_data[-1])
        if padding_len < 1 or padding_len > min(block_size, pdata_len):
            #raise ValueError("Padding is incorrect.")
            return "Padding is incorrect."
        if style == 'pkcs7':
            if padded_data[-padding_len:] != chr(padding_len)*padding_len:
                #raise ValueError("PKCS#7 padding is incorrect.")
                return "PKCS#7 padding is incorrect."
        else:
            if padded_data[-padding_len:-1] != chr(0)*(padding_len-1):
                #raise ValueError("ANSI X.923 padding is incorrect.")
                return "ANSI X.923 padding is incorrect."
    elif style == 'iso7816':
        padding_len = pdata_len - padded_data.rfind(chr(128))
        if padding_len < 1 or padding_len > min(block_size, pdata_len):
            #raise ValueError("Padding is incorrect.")
            return "Padding is incorrect."
        if padding_len > 1 and padded_data[1-padding_len:] != chr(0)*(padding_len-1):
            #raise ValueError("ISO 7816-4 padding is incorrect.")
            return "ISO 7816-4 padding is incorrect."
    else:
        #raise ValueError("Unknown padding style")
        return "Unknown padding style"
    return padded_data[:-padding_len]
def decode_tvtap(url):
    import requests
    player_user_agent = "mediaPlayerhttp/2.1 (Linux;Android 5.1) ExoPlayerLib/2.6.1"
    ch_id=url.split('$$$$')[1]
    key = b"19087321"
    
    from resources.modules.pyDes  import des, PAD_PKCS5
    from base64 import b64decode, urlsafe_b64encode
    user_agent = "Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTS Build/LVY48F)"
    token_url = "http://tvtap.net/tvtap1/index_tvtappro.php?case=get_channel_link_with_token_tvtap_updated"
    list_url = "http://tvtap.net/tvtap1/index_new.php?case=get_all_channels"
    r = requests.post(list_url, headers={"app-token": "9120163167c05aed85f30bf88495bd89"}, data={"username": "603803577"}, timeout=15)
    ch = r.json()
    for c in ch["msg"]["channels"]:
        if c["pk_id"] == ch_id:
            selected_channel = c
            break

    title = selected_channel.get("channel_name")
    image = "http://tvtap.net/tvtap1/{0}|User-Agent={1}".format(quote(c.get("img"), "/"), quote(user_agent))

    logging.warning(selected_channel)
    r = requests.post(token_url, headers={"app-token": "9120163167c05aed85f30bf88495bd89"}, data={"channel_id": ch_id, "username": "603803577"}, timeout=15)
    
    links = []
    for stream in r.json()["msg"]["channel"][0].keys():
        if "stream" in stream or "chrome_cast" in stream:
            d = des(b"98221122")
            link = d.decrypt(b64decode(r.json()["msg"]["channel"][0][stream]))
            if "dummytext" not in  link and len(link)>0:
                logging.warning(link)
                link = unpad(link, 8).decode("utf-8")
                
                if link:
                    
                    
                    if not link == "dummytext" and link not in links:
                        if link.startswith("http"):
                            links.append(link)

    
    
    link = links[0]

    if link.startswith("http"):
        media_url = "{0}|User-Agent={1}".format(link, urllib.quote('mediaPlayerhttp/1.9 (Linux;Android 5.1) ExoPlayerLib/2.6.1'))
    else:
        media_url = link
    return media_url
def quote(s, safe=""):
    
    return orig_quote(s.encode("utf-8"), safe.encode("utf-8"))
def world_chan():
    import requests
    cat_id=None
    user_agent = "Dalvik/2.1.0 (Linux; U; Android 5.1.1; AFTS Build/LVY48F)"
    token_url = "http://tvtap.net/tvtap1/index_new.php?case=get_channel_link_with_token_tvtap"
    list_url = "http://tvtap.net/tvtap1/index_new.php?case=get_all_channels"
    list_items = []
    r = requests.post(list_url, headers={"app-token": "9120163167c05aed85f30bf88495bd89"}, data={"username": "603803577"}, timeout=15)
    
    ch = r.json()
    
    for c in ch["msg"]["channels"]:
        
            image = "http://tvtap.net/tvtap1/{0}|User-Agent={1}".format(quote(c.get("img"), "/"), quote(user_agent))
            all_d=[]
            # all_d.append(addLink(name.replace('%27',"'"),url,47,False,icon,fan,free.replace('%27',"'"),video_info=urllib.unquote_plus(video_info),id=id))
            
            all_d.append(addLink(c["channel_name"],'tvtap$$$$'+c["pk_id"],47,False,iconimage=image,fanart=image,description=c["channel_name"]))
            # addLink(c["channel_name"],'tvtap$$$$'+c["pk_id"],5,False,iconimage=image,fanart=image,description=c["channel_name"])
            xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def resolve_linksdarot(url,id,plot,name1):
    import requests
    if 'tv4kids' in url:
        url=urllib.unquote_plus(url).replace('[[OS]]','')
        logging.warning('f_url:'+url.replace('[[OS]]','').decode('utf8'))
        headers = {
            'authority': 'tv4kids.tk',
            'upgrade-insecure-requests': '1',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8,application/signed-exchange;v=b3;q=0.9',
            'sec-fetch-site': 'none',
            'sec-fetch-mode': 'navigate',
            'accept-encoding': 'gzip, deflate, br',
            'accept-language': 'en-US,en;q=0.9',
            
        }

        response = requests.get(url, headers=headers,stream=True).url
        


        headers = {
            'authority': 'tv4kids.tk',
            'accept-encoding': 'identity;q=1, *;q=0',
            'user-agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/79.0.3945.117 Safari/537.36',
            'accept': '*/*',
            'sec-fetch-site': 'same-origin',
            'sec-fetch-mode': 'no-cors',
            'referer':url.replace('[[OS]]',''),
            'accept-language': 'en-US,en;q=0.9',
           
        }
        
        head=urllib.urlencode(headers)
        url=url+"|"+head
        url=response
        
    if 'drive.google.com' in url:
        from resources.modules.google_solve import googledrive_resolve
        regex='\[\[(.+?)\]\]'
        match2=re.compile(regex).findall(url)
        if len(match2)>0:
           
            url=url.replace(match2[0],'').replace('[','').replace(']','').strip()
        
        url,q=googledrive_resolve(url)
    if '%%%' in url:
        regex='\[\[(.+?)\]\]'
        match2=re.compile(regex).findall(url)
        if len(match2)>0:
           
            url=url.replace(match2[0],'').replace('[','').replace(']','').strip()
        url=url.split('%%%')[0]
        url_id=url
        url='plugin://plugin.video.telemedia/?url=%s&no_subs=%s&season=%s&episode=%s&mode=40&original_title=%s&id=%s&data=&fanart=&url=%s&iconimage=&file_name=%s&description=%s&resume=%s&name=%s&heb_name=%s'%(url_id,'1','%20','%20',name1.decode('utf-8','ignore').encode("utf-8"),id,url_id,name1.decode('utf-8','ignore').encode("utf-8"),plot,'',name1,name1)
        logging.warning(url)
    if '[' in url and 'http' not in url:
       from resources.modules.sdarot import MyResolver
       url_data=json.loads(url)
       logging.warning('Doner Test Resolve:')
       url, cookie=get_final_video_and_cookie(url_data[0], url_data[1], url_data[2], False, False)
    if 'f2h' in url:
        url=url.replace('nana10.co.il','io')
        headers = {
        'Pragma': 'no-cache',
        
        'Accept-Encoding': 'utf8',

        'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/65.0.3325.181 Safari/537.36',


        
        }
        html=requests.get(url,headers=headers).content
        
        regex='<script.+?"(.+?)/ip.php'
        match=re.compile(regex).findall(html)

        for links in match:
         
         if 'f2h.co.il' in links:
           id=links

        regex2="<form name='myform' id='myform' method='post' action='.+?/thanks/(.+?)'"
        match2=re.compile(regex2).findall(html)

        url=id+'/files/'+match2[0].replace("|","%7C")
    if 'www.youtube.com' in url :
        vid=re.compile('\?(?:v|id)=(.+?)(?:$|&)').findall(url)[0]
        url='plugin://plugin.video.youtube/play/?video_id='+vid
    return url
def play_linksdarot(name,url,video_info,id,icon,fan,plot):
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    if 'tv_title' in video_info:
        table_name='last_played_tv'
    else:
        table_name='last_played_movie'
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%table_name )
    dbcur.execute("DELETE FROM "+table_name)
    dbcur.execute("INSERT INTO %s Values ('%s','%s','%s','%s','%s','%s','%s')"%(table_name,name.replace("'","%27"),url,urllib.quote_plus(video_info),id,icon,fan,plot.replace("'","%27")))
    
    dbcon.commit()
    dbcur.close()
    dbcon.close()

    all_data=json.loads(video_info)
    all_f_name=[]
    if '$$$' in url:
       links=url.split('$$$')
       sour_pre=''
       sour=''
       all_s=[]
       for lk in links:
           f_name=''
           regex='\[\[(.+?)\]\]'
           match=re.compile(regex).findall(str(lk))
           if len(match)==0:
               if 'TEME' in lk:
                 ff_link=lk
                 f_name=lk.split('%%%')[1].split('_')[1]
                 
                 ff_link=fn.replace(match2[0],'').replace('[','').replace(']','')
                 match=[('TE',f_name)]
               else:
                    regex='//(.+?)/'
                     
                    match_ser=re.compile(regex).findall(str(lk))
            
                    if len(match_ser)>0:
                         match=[]
                         match.append((sour,match_ser[0]))
                    else:
                        match=[]
                        match.append((sour,'Direct'))
           else:
                if 'TEME' in lk:
                 logging.warning(lk)
                 ff_link=lk
                 f_name=lk.split('%%%')[1].split('_')[1]
                 
                 match=[('TE',f_name)]
                 
                else:
                    regex='\[\[(.+?)\]\].+?//(.+?)/'
                    match=re.compile(regex).findall(str(lk))
                if len(match)==0:
                    if 'TEME' in lk:
                     ff_link=lk
                     f_name=lk.split('%%%')[1].split('_')[1]
                     
                     match=[('TE',f_name)]
                     
                    else:
                        regex='\[\[(.+?)\]\]'
                        sour=re.compile(regex).findall(str(lk))[0]
                        match=[]
                        match.append((sour,'Direct'))
           
           for sour,ty in match:
                all_f_name.append(f_name)
                sour=sour.replace('openload','vummo')
                ty=ty.replace('tv4kids','streamango').replace('.tk','.com')
                if 'sratim' in ty:
                    ty='str'
                all_s.append('[COLOR lightblue][B]'+sour+'[/B][/COLOR] - [COLOR yellow][I]'+ty.replace('letsupload','avlts')+'[/I][/COLOR]')
                
       #logging.warning(all_s)
       
       ret = xbmcgui.Dialog().select("בחר", all_s)
       if ret!=-1:
         #logging.warning(links)
         #logging.warning(ret)
         ff_link=links[ret]
         
         regex='\[\[(.+?)\]\]'
         match2=re.compile(regex).findall(links[ret])
         if len(match2)>0:
           if 'TE' in all_s[ret]:
            
            
            ff_link=ff_link
            logging.warning('ff_link2:'+ff_link)
           if 'http' in ff_link or 'TE' in all_s[ret]:
            ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
           else:
            ff_link=ff_link.replace(match2[0],'')
         else:
            try:
                if 'http' in ff_link:
                    ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
                else:
                    ff_link=ff_link.replace(match2[0],'')
            except:
                pass
         logging.warning('ff_link:'+ff_link)
        
         if 'TE' in all_s[ret]:
            
            
            heb_name=all_f_name[ret]
            saved_name=all_f_name[ret]
            original_title=all_f_name[ret]
            season='%20'
            
         url=ff_link.strip()
       else:
         sys.exit()
    
    url=resolve_linksdarot(url,id,all_data['plot'],name)
    listItem = xbmcgui.ListItem(all_data['title'], path=url) 
    listItem.setInfo(type='Video', infoLabels=all_data)


    listItem.setProperty('IsPlayable', 'true')
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
def play_linkdubkids(name,url,video_info,id,icon,fan,plot,year):
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    if 'tv_title' in video_info:
        table_name='last_played_tv'
    else:
        table_name='last_played_movie'
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%table_name )
    dbcur.execute("DELETE FROM "+table_name)
    dbcur.execute("INSERT INTO %s Values ('%s','%s','%s','%s','%s','%s','%s')"%(table_name,name.replace("'","%27"),url,urllib.quote_plus(video_info),id,icon,fan,plot.replace("'","%27")))
    
    dbcon.commit()
    dbcur.close()
    dbcon.close()

    all_data=json.loads(video_info)
    all_f_name=[]
    if '$$$' in url:
       links=url.split('$$$')
       sour_pre=''
       sour=''
       all_s=[]
       for lk in links:
           f_name=''
           regex='\[\[(.+?)\]\]'
           match=re.compile(regex).findall(str(lk))
           if len(match)==0:
               if 'TEME' in lk:
                 ff_link=lk
                 f_name=lk.split('%%%')[1].split('_')[1]
                 
                 ff_link=fn.replace(match2[0],'').replace('[','').replace(']','')
                 match=[('TE',f_name)]
               else:
                    regex='//(.+?)/'
                     
                    match_ser=re.compile(regex).findall(str(lk))
            
                    if len(match_ser)>0:
                         match=[]
                         match.append((sour,match_ser[0]))
                    else:
                        match=[]
                        match.append((sour,'Direct'))
           else:
                if 'TEME' in lk:
                 logging.warning(lk)
                 ff_link=lk
                 f_name=lk.split('%%%')[1].split('_')[1]
                 
                 match=[('TE',f_name)]
                 
                else:
                    regex='\[\[(.+?)\]\].+?//(.+?)/'
                    match=re.compile(regex).findall(str(lk))
                if len(match)==0:
                    if 'TEME' in lk:
                     ff_link=lk
                     f_name=lk.split('%%%')[1].split('_')[1]
                     
                     match=[('TE',f_name)]
                     
                    else:
                        regex='\[\[(.+?)\]\]'
                        sour=re.compile(regex).findall(str(lk))[0]
                        match=[]
                        match.append((sour,'Direct'))
           
           for sour,ty in match:
                all_f_name.append(f_name)
                sour=sour.replace('openload','vummo')
                ty=ty.replace('tv4kids','streamango').replace('.tk','.com')
                if 'sratim' in ty:
                    ty='str'
                all_s.append('[COLOR lightblue][B]'+sour+'[/B][/COLOR] - [COLOR yellow][I]'+ty.replace('letsupload','avlts')+'[/I][/COLOR]')
                
       #logging.warning(all_s)
       
       ret = xbmcgui.Dialog().select("בחר", all_s)
       if ret!=-1:
         #logging.warning(links)
         #logging.warning(ret)
         ff_link=links[ret]
         
         regex='\[\[(.+?)\]\]'
         match2=re.compile(regex).findall(links[ret])
         if len(match2)>0:
           if 'TE' in all_s[ret]:
            
            
            ff_link=ff_link
            logging.warning('ff_link2:'+ff_link)
           if 'http' in ff_link or 'TE' in all_s[ret]:
            ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
           else:
            ff_link=ff_link.replace(match2[0],'')
         else:
            try:
                if 'http' in ff_link:
                    ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
                else:
                    ff_link=ff_link.replace(match2[0],'')
            except:
                pass
         logging.warning('ff_link:'+ff_link)
        
         if 'TE' in all_s[ret]:
            
            
            heb_name=all_f_name[ret]
            saved_name=all_f_name[ret]
            original_title=all_f_name[ret]
            season='%20'
            
         url=ff_link.strip()
       else:
         sys.exit()
    
    url=resolve_linkkids(url,id,all_data['plot'],icon,name,fan)
    listItem = xbmcgui.ListItem(all_data['title'], path=url) 
    listItem.setInfo(type='Video', infoLabels=all_data)


    listItem.setProperty('IsPlayable', 'true')
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
def play_linkpurn(name,url,video_info,id,icon,fan,plot,year):
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(tmdb_data_dir, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    if 'tv_title' in video_info:
        table_name='last_played_tv'
    else:
        table_name='last_played_movie'
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%table_name )
    dbcur.execute("DELETE FROM "+table_name)
    dbcur.execute("INSERT INTO %s Values ('%s','%s','%s','%s','%s','%s','%s')"%(table_name,name.replace("'","%27"),url,urllib.quote_plus(video_info),id,icon,fan,plot.replace("'","%27")))
    
    dbcon.commit()
    dbcur.close()
    dbcon.close()

    all_data=json.loads(video_info)
    all_f_name=[]
    if '$$$' in url:
       links=url.split('$$$')
       sour_pre=''
       sour=''
       all_s=[]
       for lk in links:
           f_name=''
           regex='\[\[(.+?)\]\]'
           match=re.compile(regex).findall(str(lk))
           if len(match)==0:
               if 'TEME' in lk:
                 ff_link=lk
                 f_name=lk.split('%%%')[1].split('_')[1]
                 
                 # ff_link=fn.replace(match2[0],'').replace('[','').replace(']','')
                 match=[('TE',f_name)]
               else:
                    regex='//(.+?)/'
                     
                    match_ser=re.compile(regex).findall(str(lk))
            
                    if len(match_ser)>0:
                         match=[]
                         match.append((sour,match_ser[0]))
                    else:
                        match=[]
                        match.append((sour,'Direct'))
           else:
                if 'TEME' in lk:
                 logging.warning(lk)
                 ff_link=lk
                 f_name=lk.split('%%%')[1].split('_')[1]
                 
                 match=[('TE',f_name)]
                 
                else:
                    regex='\[\[(.+?)\]\].+?//(.+?)/'
                    match=re.compile(regex).findall(str(lk))
                if len(match)==0:
                    if 'TEME' in lk:
                     ff_link=lk
                     f_name=lk.split('%%%')[1].split('_')[1]
                     
                     match=[('TE',f_name)]
                     
                    else:
                        regex='\[\[(.+?)\]\]'
                        sour=re.compile(regex).findall(str(lk))[0]
                        match=[]
                        match.append((sour,'Direct'))
           
           for sour,ty in match:
                all_f_name.append(f_name)
                sour=sour.replace('openload','vummo')
                ty=ty.replace('tv4kids','streamango').replace('.tk','.com')
                if 'sratim' in ty:
                    ty='str'
                all_s.append('[COLOR lightblue][B]'+sour+'[/B][/COLOR] - [COLOR yellow][I]'+ty.replace('letsupload','avlts')+'[/I][/COLOR]')
                
       #logging.warning(all_s)
       
       # ret = xbmcgui.Dialog().select("בחר", all_s)
       # if ret!=-1:
         # #logging.warning(links)
         # #logging.warning(ret)
         # ff_link=links[ret]
         
         # regex='\[\[(.+?)\]\]'
         # match2=re.compile(regex).findall(links[ret])
         # if len(match2)>0:
           # if 'TE' in all_s[ret]:
            
            
            # ff_link=ff_link
            # logging.warning('ff_link2:'+ff_link)
           # if 'http' in ff_link or 'TE' in all_s[ret]:
            # ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
           # else:
            # ff_link=ff_link.replace(match2[0],'')
         # else:
            # try:
                # if 'http' in ff_link:
                    # ff_link=ff_link.replace(match2[0],'').replace('[','').replace(']','')
                # else:
                    # ff_link=ff_link.replace(match2[0],'')
            # except:
                # pass
         # logging.warning('ff_link:'+ff_link)
        
         # if 'TE' in all_s[ret]:
            
            
            # heb_name=all_f_name[ret]
            # saved_name=all_f_name[ret]
            # original_title=all_f_name[ret]
            # season='%20'
            
         # url=ff_link.strip()
       # else:
         # sys.exit()
    
    url=resolve_linkkids(url,id,all_data['plot'],icon,name,fan,all_data['year'],all_data['tmdb'])
    listItem = xbmcgui.ListItem(all_data['title'], path=url) 
    listItem.setInfo(type='Video', infoLabels=all_data)


    listItem.setProperty('IsPlayable', 'true')
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)
    
    
def playiptv(name,url,iconimage,fanart):


     if 'tvtap' in url:
        url=decode_tvtap(url)

     video_data={}
     video_data['title']=(xbmc.getInfoLabel("ListItem.title"))
     video_data['poster']=(xbmc.getInfoLabel("ListItem.Art(thumb)"))
     video_data['fanart']=(xbmc.getInfoLabel("ListItem.Art(thumb)"))
     video_data['plot']=''
     video_data['icon']=(xbmc.getInfoLabel("ListItem.Art(thumb)"))
     listItem = xbmcgui.ListItem(video_data['title'],iconImage=iconimage, thumbnailImage=iconimage, path=url) 
     # listItem = xbmcgui.ListItem(name,iconImage=iconimage, thumbnailImage=iconimage, path=link) 
     listItem.setInfo(type='Video', infoLabels=video_data)
     ok=xbmc.Player().play(url,listitem=listItem)
     ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)


    
    
    
    
    
def save_fav(name,url,iconimage,fanart,description,video_info):
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(addonPath, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""iconimage TEXT,""fanart TEXT,""description TEXT,""free TEXT,""free2 TEXT);"%'Fav' )
    
    dbcur.execute("INSERT INTO Fav Values ('%s','%s','%s','%s','%s','%s','')"%(name.replace("'","%27"),url,iconimage,fanart,description,video_info.replace("'","%27")))
    
    dbcon.commit()
    dbcur.close()
    dbcon.close()
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kids', 'נשמר')))
def show_fav():
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(addonPath, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""iconimage TEXT,""fanart TEXT,""description TEXT,""free TEXT,""free2 TEXT);"%'Fav' )

    dbcon.commit()
    
    dbcur.execute("SELECT * FROM Fav")
    match = dbcur.fetchall()
    all_d=[]
    for name ,url ,icon ,fan ,plot,free,free2 in match:
        try:
            video_data=json.loads(free.replace("%27","'"))
        except: 
            video_data={}
            video_data['title']=name.replace("%27","'")
            video_data['icon']=icon
            video_data['fanart']=fan
            video_data['plot']=plot.replace("%27","'")
        video_data['fast']=1
        
        all_d.append(addDir3(name.replace('%27',"'"),url,46,icon,fan,plot.replace('%27',"'"),video_info=video_data))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    dbcur.close()
    dbcon.close()
def moviecontinew():
    all_d=[]
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(addonPath, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    match=[('0')]
    match_tv=[('0')]
    try:
        dbcur.execute("SELECT * FROM updated where type='movies'")
        match = dbcur.fetchall()
        logging.warning(match)
        dbcur.execute("SELECT * FROM updated where type='tv'")
        match_tv = dbcur.fetchall()
        logging.warning(match)
    except:
        pass
    if len(match)==0:
        match=[('0')]
    if len(match_tv)==0:
        match_tv=[('0')]
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'kids_movie')
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""con1 TEXT,""origin TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""data TEXT);"% 'newones')
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""link TEXT,""icon TEXT, ""image TEXT,""plot TEXT,""origin TEXT);"% 'kids_show')
    
    dbcur.execute("SELECT * FROM kids_movie")

    match2 = dbcur.fetchall()
    all_names=[]
    count_m=0
    for name1,link,con1,origin,icon,image,plot,data in match2:
        if name1 not in all_names:
            all_names.append(name1)
            count_m+=1
    dbcur.execute("SELECT * FROM kids_show ")

    match2 = dbcur.fetchall()
    all_names=[]
    count_tv=0
    for name1,link,icon,image,plot,origin in match2:
        if name1 not in all_names:
            all_names.append(name1)
            count_tv+=1
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%'last_played_movie' )
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""video_info TEXT,""id TEXT,""icon TEXT,""fan TEXT,""free TEXT);"%'last_played_tv' )
   
    dbcur.execute("SELECT * FROM last_played_movie")
    match = dbcur.fetchall()
    for name ,url ,video_info ,id ,icon ,fan ,free in match:
        all_d.append(addLink(name.replace('%27',"'"),url,5,False,icon,fan,free.replace('%27',"'"),video_info=urllib.unquote_plus(video_info),id=id))
    dbcur.execute("SELECT * FROM last_played_tv")
    match = dbcur.fetchall()
    for name ,url ,video_info ,id ,icon ,fan ,free in match:
        all_d.append(addLink(name.replace('%27',"'"),url,5,False,icon,fan,free.replace('%27',"'"),video_info=urllib.unquote_plus(video_info),id=id))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    dbcur.close()
    dbcon.close()
def remove_fav(name,url,iconimage,fanart,description):
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    addonPath = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
    tmdb_data_dir = addonPath#os.path.join(addonPath, 'resources', 'tmdb_data')
    tmdb_cacheFile = os.path.join(addonPath, 'youtube.db')
    dbcon = database.connect(tmdb_cacheFile)
    dbcur = dbcon.cursor()
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT,""url TEXT,""iconimage TEXT,""fanart TEXT,""description TEXT,""free TEXT,""free2 TEXT);"%'Fav' )
    
    dbcur.execute("DELETE FROM Fav Where name='%s'"%(name.replace("'","%27")))
    
    dbcon.commit()
    dbcur.close()
    dbcon.close()
    xbmc.executebuiltin('Container.Refresh')
    xbmc.executebuiltin((u'Notification(%s,%s)' % ('Kids', 'הוסר')))
Addon = xbmcaddon.Addon()
COLOR2='yellow'
COLOR1='white'
ADDONTITLE='הכל לילדים'
iconx = Addon.getAddonInfo('icon')
DIALOG         = xbmcgui.Dialog()
def LogNotify(title, message, times=2000, icon=iconx,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound)
def updatewall():
    from resources.modules.hebdub_movies import update_now
    from resources.modules.hebdub_kids import update_nowkids


    from resources.modules.hebdub_israel import update_nowisrael

    from resources.modules.kidstv import update_now_tv
    from resources.modules.hebdub_purn import update_nowpurn
    from resources.modules.hebdub_telekids import update_nowtelekids
    
    
    
    
    
    # from resources.modules.kidstv import update_now_tv
    # update_now(progress=True)
    # update_nowkids(progress=True)
    time.sleep(200.0)
    update_now()
    update_nowkids()
    update_nowisrael()
    update_now_tv()
    update_nowpurn()
    # update_now_tv(progress=True)
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מעודכן[/COLOR]' % COLOR2)
params=get_params()

url=None
name=None
mode=None
iconimage=None
fanart=None
description=None
id='0'
year=' '

try:
        url=urllib.unquote_plus(params["url"])
except:
        pass
try:
        name=urllib.unquote_plus(params["name"])
except:
        pass
try:
        iconimage=urllib.unquote_plus(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=urllib.unquote_plus(params["fanart"])
except:
        pass
try:        
        description=urllib.unquote_plus(params["description"])
except:
        pass
try:
    video_info=urllib.unquote_plus(params["video_info"])
except:
        pass
try:
    id=(params["id"])
except:
        pass
logging.warning('Mode:'+str(mode))
logging.warning('url:'+str(url))
#logging.warning('video_info:'+str(video_info))
if mode==None or url==None or len(url)<1:
        main_menu()
elif mode==1:
    from resources.modules.hebdub_movies import get_dub
    get_dub(url)

    
elif mode==2:
    from resources.modules.kidstv import get_links
    get_links()
    
elif mode==4:
    import datetime
    from resources.modules.kidstv import Trailer_Youtube
    now = datetime.datetime.now()
    link_url='https://www.youtube.com/results?sp=CAI%253D&q=%22%D7%98%D7%A8%D7%99%D7%99%D7%9C%D7%A8+%D7%9E%D7%93%D7%95%D7%91%D7%91%22+' + str(now.year)
    Trailer_Youtube(link_url,now)
    
elif mode==5:
    play_link(name,url,video_info,id,iconimage,fanart,description,year)
elif mode==6:
    updatewall()
elif mode==7:
    save_fav(name,url,iconimage,fanart,description,video_info)
elif mode==8:
    show_fav()
elif mode==9:
    remove_fav(name,url,iconimage,fanart,description)
elif mode==11:
       search_entered=''
       if 'search' in url :
        
        keyboard = xbmc.Keyboard(search_entered, 'הכנס מילות חיפוש כאן')
        keyboard.doModal()
        if keyboard.isConfirmed():
               search_entered = keyboard.getText()

               from resources.modules.hebdub_movies import get_dub
               get_dub(url,search_entered=search_entered)
               from resources.modules.hebdub_kids import get_dub
               get_dub(url,search_entered=search_entered)
               from resources.modules.hebdub_israel import get_dub
               get_dub(url,search_entered=search_entered)
               from resources.modules.kidstv import get_links
               get_links(search_entered=search_entered)
               
       else:
             sys.exit()


elif mode==12:
 moviecontinew()
elif mode==13:
    from resources.modules.hebdub_kids import get_dub
    get_dub(url)
elif mode==14:
    movielist()
elif mode==15:
    from resources.modules.hebdub_movies import update_now
    from resources.modules.hebdub_israel import update_nowisrael
    from resources.modules.hebdub_kids import update_nowkids
    from resources.modules.kidstv import update_now_tv
    from resources.modules.hebdub_purn import update_nowpurn
    from resources.modules.hebdub_telekids import update_nowtelekids

    update_now(progress=True)
    update_nowisrael(progress=True)
    update_nowkids(progress=True)
    update_now_tv(progress=True)
    update_nowpurn(progress=True)
    # update_nowtelekids(progress=True)
    LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]עודכן[/COLOR]' % COLOR2)
    
elif mode==16:
    play_linkdubkids(name,url,video_info,id,iconimage,fanart,description,year)
    

elif mode==17:
    from resources.modules.hebdub_israel import get_dub
    get_dub(url)
elif mode==18:
    play_linksdarot(name,url,video_info,id,iconimage,fanart,description)
elif mode==19:
    from resources.modules.hebdub_purn import get_dub
    
    
    input= '8888'
    dialog = xbmcgui.Dialog()
    search_entered=''

    keyboard = dialog.numeric(0, 'הכנס סיסמה')

    search_entered = keyboard
    if search_entered=='8888':
       get_dub(url)
    else:
      LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]סיסמה שגויה[/COLOR]' % COLOR2)
      sys.exit()
    

elif mode==20:
    play_linkpurn(name,url,video_info,id,iconimage,fanart,description,year)
elif mode==21:
    from resources.modules.hebdub_telekids import get_dub
    get_dub(url)
elif mode==22:
    from resources.modules.hebdub_purn import get_dub
    
    get_dub(url)
elif mode==35:
    DIALOG         = xbmcgui.Dialog()
    choice = DIALOG.yesno(ADDONTITLE, "לנקות את המאגר?", yeslabel="[B][COLOR yellow]כן[/COLOR][/B]", nolabel="[B][COLOR white]לא[/COLOR][/B]")
    if choice == 1:
        ClearCache()
        
    else:
     sys.exit()
elif mode==46:
    from resources.modules.kidstv_season import get_seasons
    get_seasons(name,url,iconimage,fanart,description)
    
    
elif mode==47:
     
     playiptv(name,url,iconimage,fanart)
elif mode==48:
    world_chan()
elif mode==49:
      play_trailer(id)
xbmcplugin.setContent(int(sys.argv[1]), 'movies')


xbmcplugin.endOfDirectory(int(sys.argv[1]))

