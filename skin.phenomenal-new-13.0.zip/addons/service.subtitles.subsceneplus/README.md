Subscene Plus Kodi addon
========================

Subscene plus is a kodi addon intended to fasilitate downloading subtitles from subscene.com. Subscene.com does not provide an API. Hence, subscene plus works by automatically parsing the HTML files and downloading them.

TV-shows are not currently tested, but give it a try, it might work.

Official repository:  
* https://github.com/Cih2001/KodiSubsceneAddon

Big shoutout to:  
* https://github.com/amet/service.subtitles.demo/
* https://github.com/amet/service.subtitles.opensubtitles
* https://github.com/manacker/service.subtitles.subscene