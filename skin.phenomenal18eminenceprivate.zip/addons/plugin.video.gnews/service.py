# -*- coding: utf-8 -*-
import xbmc,time,xbmcaddon,os,requests,xbmcgui,re
update_time=15#60*60 #one hour
tv_sc='https://pastebin.com/raw/NKxxmmLQ'

Addon = xbmcaddon.Addon()
last_run=0

user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile")).decode("utf-8")
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)
     
tv_file=os.path.join(user_dataDir,"tv_sch.txt")
ACTION_PREVIOUS_MENU 			=  10	## ESC action
ACTION_NAV_BACK 				=  92	## Backspace action
def TextBox(title, msg):
	class TextBoxes(xbmcgui.WindowXMLDialog):
		def onInit(self):
			self.title      = 101
			self.msg        = 102
			self.scrollbar  = 103
			self.okbutton   = 201
			self.y=0
			self.showdialog()

		def showdialog(self):
			self.getControl(self.title).setLabel(title)
			self.getControl(self.msg).setText(msg)
			self.setFocusId(self.okbutton)
			
		def onClick(self, controlId):
			if (controlId == self.okbutton):
				self.close()
		
		def onAction(self, action):
			if   action == ACTION_PREVIOUS_MENU: self.close()
			elif action == ACTION_NAV_BACK: self.close()
	
			
	tb = TextBoxes( "Textbox.xml" , Addon.getAddonInfo('path'), 'DefaultSkin', title=title, msg=msg)
	tb.doModal()
	del tb
def tv_sch():
   tv_svh=requests.get(tv_sc, stream=True)
   all_txt=[]
   for line in tv_svh.iter_lines():
     
         if 'date-' in line:
           all_txt.append(line.replace('date-','[COLOR aqua]').replace('"','')+'[/COLOR]')
         elif 'end date' in line:
            all_txt.append('\n')
         elif 'end chan' in line:
           all_txt.append('\n')
         elif  'chan name'  in line:
           all_txt.append(line.replace('chan name:','[COLOR yellow]')+'[/COLOR]')
         elif ':' in line:
           regex='s(.+?)e(.+?)$'
           match=re.compile(regex).findall(line.split('-')[1])
           if len(match)>0:
             extra=' עונה ' +match[0][0]+' פרק '+match[0][1]
           else:
             extra=''
           all_txt.append(line.split('-')[0]+line.split('-')[1].split(':')[0]+'  -  '+extra)
           
         else:
           all_txt.append(line)
   TextBox('חדשות מדיה סנטר', '\n'.join(all_txt))
   
while not xbmc.abortRequested:
    if(time.time() > last_run + update_time) and not xbmc.Player().isPlaying():
                  now = time.time()
                  last_run = now - (now % update_time)
                  if Addon.getSetting("alert")=='true':
                      x=requests.get(tv_sc).content
                      
                      if os.path.exists(tv_file):
                        file = open(tv_file, 'r') 
                        tv_file_cont= file.read() 
                        if tv_file_cont!=x:
                            file = open(tv_file,'w') 
         
                            file.write(x) 

         
                            file.close() 
                            tv_sch()
                      else:
                        file = open(tv_file,'w') 
     
                        file.write(x) 

     
                        file.close() 
                        tv_sch()
                  
    xbmc.sleep(1000)
               
                             