# -*- coding: utf-8 -*-
import xbmc,time,logging,datetime,xbmcaddon,xbmcgui

from resources.modules.hebdub_movies import update_now
from resources.modules.hebdub_kids import update_nowkids


from resources.modules.hebdub_israel import update_nowisrael

from resources.modules.kidstv import update_now_tv
from resources.modules.hebdub_purn import update_nowpurn
from resources.modules.hebdub_telekids import update_nowtelekids




Addon = xbmcaddon.Addon()
logging.warning('Nextup Service Started')

START=True


COLOR2='yellow'
COLOR1='white'
ADDONTITLE='הכל לילדים'
iconx = Addon.getAddonInfo('icon')
DIALOG         = xbmcgui.Dialog()

def LogNotify(title, message, times=2000, icon=iconx,sound=False):
	DIALOG.notification(title, message, icon, int(times), sound) 


monitor = xbmc.Monitor()


logging.warning('!!!!!!!!!!!!!!!!!!Start הכל לילדים service!!!!!!!!!!!!!!!!!!')

strings = time.strftime("%Y,%m,%d,%H,%M,%S")
t = strings.split(',')
numbers = [ int(x) for x in t ]
pre_date=numbers[2]
while not monitor.abortRequested():
 
    if monitor.waitForAbort(1):
            # Abort was requested while waiting. We should exit
            
            break
    
   
    
 
    START=False
    strings = time.strftime("%Y,%m,%d,%H,%M,%S")
    t = strings.split(',')
    numbers = [ int(x) for x in t ]
    
    if numbers[3]==int(Addon.getSetting("update_kids")) and numbers[2]!=pre_date:
        # logging.warning('Updating now Hebdub')
        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]מעדכן קיר סרטים[/COLOR]' % COLOR2)
        pre_date=numbers[2]
        update_now()
        update_nowkids()
        update_nowisrael()
        update_now_tv()
        update_nowpurn()
        

        LogNotify("[COLOR %s]%s[/COLOR]" % (COLOR1, ADDONTITLE),'[COLOR %s]הכל מעודכן[/COLOR]' % COLOR2)

       
    xbmc.sleep(1000)
del monitor
               
                             