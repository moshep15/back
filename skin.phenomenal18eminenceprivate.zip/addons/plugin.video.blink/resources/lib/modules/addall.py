import xbmcgui,sys,xbmc,xbmcplugin,logging,json
KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
def utf8_urlencode(params):
    try:
        import urllib as u
        enc=u.urlencode
    except:
        from urllib.parse import urlencode
        enc=urlencode
    # problem: u.urlencode(params.items()) is not unicode-safe. Must encode all params strings as utf8 first.
    # UTF-8 encodes all the keys and values in params dictionary
    for k,v in list(params.items()):
        # TRY urllib.unquote_plus(artist.encode('utf-8')).decode('utf-8')
        if type(v) in (int, float):
            params[k] = v
        else:
            try:
                params[k.encode('utf-8')] = v.encode('utf-8')
            except Exception as e:
                pass
                #logging.warning( '**ERROR utf8_urlencode ERROR** %s' % e )
    
    return enc(params).encode().decode('utf-8')
def addNolink( name, url,mode,isFolder, iconimage="DefaultFolder.png",fanart="DefaultFolder.png"):
 

          params={}
          params['url']=url
          params['mode']=mode
          params['name']=name
        
          all_ur=utf8_urlencode(params)
          u=sys.argv[0]+"?mode="+str(mode)+'&'+all_ur
         
         
          if KODI_VERSION<=18:
            liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)
          else:
            liz = xbmcgui.ListItem( name)
          liz.setInfo(type="Video", infoLabels={ "Title": ( name)   })
          liz.setProperty( "Fanart_Image", fanart )
          art = {}
          art.update({'poster': iconimage,'icon': iconimage,'thumb': iconimage})
          liz.setArt(art)
          liz.setProperty("IsPlayable","false")
          liz.setProperty( "Fanart_Image", iconimage )
          #xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
          return u,liz,False
###############################################################################################################        

def addDir3(name,url,mode,iconimage,fanart,description,page='0',video_data={},imdb_id='',season='',episode='',totalepisodes=''):
        params={}
        params['url']=url
        params['mode']=mode
        params['name']=name
        params['imdb_id']=imdb_id
        params['iconimage']=iconimage
        params['fanart']=fanart
        params['description']=description
        params['page']=page
        params['season']=season
        params['episode']=episode
        params['video_data']=json.dumps(video_data)
        all_ur=utf8_urlencode(params)
        u=sys.argv[0]+"?mode="+str(mode)+'&'+all_ur
        
        
        ok=True
        if KODI_VERSION<=18:
            liz=xbmcgui.ListItem(name, iconImage=iconimage, thumbnailImage=iconimage)
        else:
            liz=xbmcgui.ListItem(name)
        if 'imdb_id' in video_data:
            video_data.pop('imdb_id')
        if 'original_name' in video_data:
            video_data.pop('original_name')

        
        liz.setInfo( type="Video", infoLabels=video_data )
        liz.setProperty( "Fanart_Image", fanart )
        

        liz.setProperty('WatchedEpisodes', '0')
        liz.setProperty('UnWatchedEpisodes', str(totalepisodes))

        art = {}
        art.update({'poster': iconimage,'icon': iconimage,'thumb': iconimage})
        liz.setArt(art)
        return u,liz,True
        #ok=xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]),url=u,listitem=liz,isFolder=True)
        
        #return ok



def addLink( name, url,mode, iconimage,fanart,description,video_data,imdb_id='',actors=[]):
          params={}
          params['url']=url

          params['name']=name
          params['video_data']=json.dumps(video_data)
          params['iconimage']=iconimage
          params['fanart']=fanart
          params['description']=description
          params['imdb_id']=imdb_id
          all_ur=utf8_urlencode(params)
          u=sys.argv[0]+"?mode="+str(mode)+'&'+all_ur
          
          
          video_info=video_data
          
        
       
          
          #u=sys.argv[0]+"?url="+que(url)+"&mode="+str(mode)+"&name="+que(name)
          if KODI_VERSION<=18:
            liz = xbmcgui.ListItem( name, iconImage=iconimage, thumbnailImage=iconimage)
          else:
            liz = xbmcgui.ListItem( name)
          if 'imdb_id' in video_info:
                video_info.pop('imdb_id')
          if 'original_name' in video_info:
                video_info.pop('original_name')
          liz.setInfo(type="Video", infoLabels=video_info)
          liz.setCast(actors)
          art = {}
          art.update({'poster': iconimage,'icon': iconimage,'thumb': iconimage})
          liz.setArt(art)
          liz.setProperty("IsPlayable","true")
          liz.setProperty( "Fanart_Image", fanart )
          #xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=liz,isFolder=isFolder)
          return u,liz,False