# -*- coding: utf-8 -*-
import xbmcaddon,os,xbmc,xbmcgui,urllib,re,xbmcplugin,sys,logging,json,base64
import threading,time,xbmcvfs

__USERAGENT__ = 'Mozilla/5.0 (Windows NT 6.1; WOW64) AppleWebKit/537.11 (KHTML, like Gecko) Chrome/23.0.1271.97 Safari/537.11'
__addon__ = xbmcaddon.Addon()
__cwd__ = xbmc.translatePath(__addon__.getAddonInfo('path'))
Addon = xbmcaddon.Addon()
user_dataDir = xbmc.translatePath(Addon.getAddonInfo("profile"))
if not os.path.exists(user_dataDir):
     os.makedirs(user_dataDir)

KODI_VERSION = int(xbmc.getInfoLabel("System.BuildVersion").split('.', 1)[0])
if KODI_VERSION<=18:
    xbmc_tranlate_path=xbmc.translatePath
else:
    xbmc_tranlate_path=xbmcvfs.translatePath
from resources.lib.modules.addall import addNolink,addDir3,addLink
from resources.lib.modules.client import get_html
lang=xbmc.getLanguage(0)
sources_addr=['https://torrentio.strem.fun/stream/%s/%s.json','https://torrentio.strem.fun/lite/stream/%s/%s.json','https://thepiratebay-plus.strem.fun/stream/%s/%s.json','https://pct.best4stremio.space/stremioget/stremio/v1/q.json?b=%s','https://5a0d1888fa64-torrentmafya-stremio-addon.baby-beamup.club/stream/%s/%s.json','https://juan.best4stremio.space/stremioget/stremio/v1/q.json?b=%s','https://eztv.re/api/get-torrents?imdb_id=%s&limit=100&page=%s','https://movies-v2.api-fetch.sh/%s/%s','https://torrentapi.org/pubapi_v2.php?app_id=Torapi&mode=search&search_imdb=%s&token=%s&sort=seeders&ranked=0&limit=100&format=json_extended&search_string=%s','https://stremio-yts.herokuapp.com/stream/movie/%s.json']
sources_addr=['https://torrentio.strem.fun/stream/%s/%s.json']
global all_sources,all_hash,all_error_sources,still_in_window
global string_dp2,still_alive,all_sources_final,playback_url,play_status_rd_ext,play_status,break_window,prect,original_url
original_url=''
still_in_window=False
break_window=False
prect=0
play_status=''
play_status_rd_ext=''
playback_url=''
string_dp2='a'
still_alive=1
all_sources_final=[]
all_error_sources={}
all_hash=[]
all_sources=[]
if KODI_VERSION>18:
    def trd_alive(thread):
        return thread.is_alive()
    class Thread (threading.Thread):
       def __init__(self, target, *args):
        super().__init__(target=target, args=args)
        
       def run(self, *args):
          
          self._target(*self._args)
else:
    def trd_alive(thread):
        return thread.isAlive()
    class Thread(threading.Thread):
        def __init__(self, target, *args):
           
            self._target = target
            self._args = args
            
            
            threading.Thread.__init__(self)
            
        def run(self):
            
            self._target(*self._args)


base_header={
            'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
            'Accept-Language': 'en-US,en;q=0.5',
            'Cache-Control': 'no-cache',
            'Connection': 'keep-alive',

            'Pragma': 'no-cache',
            
           
            'User-Agent': 'Mozilla/5.0 (Windows NT 6.1; Win64; x64; rv:59.0) Gecko/20100101 Firefox/59.0',
            }
if KODI_VERSION<=18:
    
    que=urllib.quote_plus
    que_n=urllib.quote
    url_encode=urllib.urlencode
    unque=urllib.unquote_plus
else:
    
    que_n=urllib.parse.quote
    que=urllib.parse.quote_plus
    url_encode=urllib.parse.urlencode
    unque=urllib.parse.unquote_plus
def get_params():
        param=[]
        if len(sys.argv)>=2:
          paramstring=sys.argv[2]
          if len(paramstring)>=2:
                params=sys.argv[2]
                cleanedparams=params.replace('?','')
                if (params[len(params)-1]=='/'):
                        params=params[0:len(params)-2]
                pairsofparams=cleanedparams.split('&')
                param={}
                for i in range(len(pairsofparams)):
                        splitparams={}
                        splitparams=pairsofparams[i].split('=')
                        if (len(splitparams))==2:
                                param[splitparams[0]]=splitparams[1]
                                
        return param     
base_icon_movies='https://scontent.fsdv1-2.fna.fbcdn.net/v/t1.0-0/c12.0.1080.1080a/s526x395/101334242_143899207216046_3157138821867372544_o.jpg?_nc_cat=106&ccb=1-3&_nc_sid=85a577&_nc_ohc=c0XXwe5fLMEAX-zWY6E&_nc_ht=scontent.fsdv1-2.fna&tp=28&oh=c4cc392d8c560559ff086e767da835fb&oe=60829897'
base_image_movies='https://eskipaper.com/images/typography-dont-blink-1.jpg'
base_icon_tv='https://dbdzm869oupei.cloudfront.net/img/sticker/preview/8058.png'
base_image_tv='https://i.ytimg.com/vi/LpKBMywiEjw/hqdefault.jpg'

def main_menu():
    all_d=[]
    all_d.append(addDir3( "[COLOR lightblue]Movies[/COLOR]", 'movie',2, base_icon_movies,base_image_movies,"Movies"))
    
    all_d.append(addDir3( "[COLOR lightblue]Series[/COLOR]", 'series',2, base_icon_tv,base_image_tv,"Series"))
    all_d.append(addDir3( "[COLOR lightblue]Last played[/COLOR]", 'www',12, 'https://www.wafj.com/sites/wafj/images/home-misc/recently_played_icon_wafj_upd.png','https://forums.launchbox-app.com/uploads/monthly_2018_06/623479109_RecentlyPlayed.png.e9777b8a14d9d1780ae0dda50e7306c1.png',"Last played"))
    
    all_d.append(addNolink( 'News', 'www',10,False, iconimage=base_icon_tv,fanart=base_image_tv))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def categories(url):
    if Addon.getSetting("meta_source")=='0':
       mode=3
    else:
       mode=9
    all_d=[]
    all_d.append(addDir3( "[COLOR lightblue]Top[/COLOR]", 'Top',mode, base_icon_movies,base_image_movies,url))
    
    all_d.append(addDir3( "[COLOR lightblue]Genres[/COLOR]", 'Genres',mode, base_icon_movies,base_image_movies,url))
    all_d.append(addDir3( "[COLOR lightblue]Years[/COLOR]", 'Years',mode, base_icon_movies,base_image_movies,url))
    all_d.append(addDir3( "[COLOR lightblue]Ratings[/COLOR]", 'Ratings',mode, base_icon_movies,base_image_movies,url))
    all_d.append(addDir3( "[COLOR lightblue]Search[/COLOR]", 'Search',mode, base_icon_movies,base_image_movies,url))
    

    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def movies_data(url,page,tv_show):
    
    all_d=[]
    headers={'user-agent': 'Stremio/1.3.4 VersionCode/6304313 Package/com.stremio.one Coolpad/C103 Android/6.0.1 Dalvik/2.1.0 (Linux; U; Android 6.0.1; C103 Build/ZIXOSOP5801711191S)',

             'Connection': 'Keep-Alive',
            'Accept-Encoding': 'utf-8'}

    if url=='Top':
        url='https://v3-cinemeta.strem.io/catalog/%s/top/'%tv_show
    elif url=='Genres':
        
        all_genre=['Action','Adventure','Animation','Biography','Comedy','Crime','Documentary','Drama','Family','Fantasy','Game-Show','History','Horror','Mystery','Romance','Sci-Fi','Sport','Thriller','War','Western']
        ret=xbmcgui.Dialog().select("Choose", all_genre)
        if ret!=-1:
            
              selected_genre=all_genre[ret]
            
        else:
            return 0
            
        url='https://v3-cinemeta.strem.io/catalog/%s/year/genre=%s&'%(tv_show,selected_genre)
    elif url=='Years':
        all_years=[]
        import datetime
        all_d=[]
        now = datetime.datetime.now()
        for year in range(now.year,1970,-1):
             all_years.append(str(year))
        ret= xbmcgui.Dialog().select("Choose", all_years)
        if ret!=-1:
            
              selected_year=all_years[ret]
            
        else:
            return 0
        url='https://v3-cinemeta.strem.io/catalog/%s/year/genre=%s&'%(tv_show,selected_year)
    elif url=='Ratings':
        url='https://v3-cinemeta.strem.io/catalog/%s/imdbRating/'%tv_show
        
    elif url=='Search':
        search_entered=''
        keyboard = xbmc.Keyboard(search_entered, 'Enter Search')
        keyboard.doModal()
        if keyboard.isConfirmed() :
               search_entered = que(keyboard.getText().replace("'",""))
               if search_entered=='':
                sys.exit()
               url='https://v3-cinemeta.strem.io/catalog/%s/top/search=%s&'%(tv_show,search_entered)
    if 'skip=' in url:
        url=url.split('skip=')[0]
    url=url+'skip=%s.json'%str(int(page)*100)
    logging.warning(url)
    x=get_html(url,headers=headers).json()
    
    for items in x['metas']:
        video_data={}
        rating=items.get('imdbRating','')
        imdb_id=items.get('imdb_id','')
        name=items['name']
        iconimage=items.get('poster','')
        fanart=items.get('background','')
        if 'runtime' in items and items['runtime']!=None:
            runtime=items['runtime'].split(' ')[0]
            video_data['duration']=int(runtime)*60
        #logging.warning(items)
        year=items.get('year','')
       
        if len(year)<4:
            year=items.get('releaseInfo','')
        description=items.get('description','Nop')
        ge=[]
        genres=items.get('genres','')
        if genres:
            for itt in genres:
                ge.append(itt)
        generes=' / '.join(ge)
        
        video_data['title']=name
        video_data['imdb_id']=imdb_id
        
        video_data['year']=year
        video_data['genre']=generes
        
        
        video_data['rating']=rating
        video_data['plot']=description
        video_data['director']=items.get('director','')
        video_data['writer']=items.get('writer','')
        actors=[]
        casts=items.get('cast','')
        if casts:
            for items in casts:
                actors.append({"name": items, "role": ""})
            
        
        if tv_show=='series':
            all_d.append(addDir3( name, 'www',5, iconimage,fanart,description,video_data=video_data,imdb_id=imdb_id))
        else:
            all_d.append(addLink( name, 'www',4, iconimage,fanart,description,video_data,imdb_id=imdb_id,actors=actors))
    if url!='Search':
        if 'hasMore' in x and x['hasMore']==True:
            all_d.append(addDir3( "[COLOR lightblue]Next page[/COLOR]", url,3, base_icon_movies,base_image_movies,tv_show,page=str(int(page)+1)))
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def get_seasons(iconimage,fanart,description,imdb_id):
    headers={'user-agent': 'Stremio/1.3.4 VersionCode/6304313 Package/com.stremio.one Coolpad/C103 Android/6.0.1 Dalvik/2.1.0 (Linux; U; Android 6.0.1; C103 Build/ZIXOSOP5801711191S)',

     'Connection': 'Keep-Alive',
    'Accept-Encoding': 'utf-8'}
    url='https://v3-cinemeta.strem.io/meta/series/%s.json'%imdb_id
    logging.warning(url)
    x=get_html(url,headers=headers).json()
    max_season=0
    all_d=[]
    totalepisodes={}
    for items in x['meta']['videos']:
        season=items['season']
        if season in totalepisodes:
            totalepisodes[season]=totalepisodes[season]+1
        else:
            totalepisodes[season]=0
        if int(season)>max_season:
            max_season=int(season)
    
    for items in range(1,max_season+1):
        video_data={}
        video_data['title']=name
        video_data['imdb_id']=imdb_id
        video_data['plot']=description
        video_data['Season']=int(items)
        video_data['mediatype']='season'
        all_d.append(addDir3( 'Season '+str(items), 'www',6, iconimage,fanart,description,video_data=video_data,imdb_id=imdb_id,season=str(items),totalepisodes=totalepisodes[items]))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def get_series(imdb_id,season_pre):
    headers={'user-agent': 'Stremio/1.3.4 VersionCode/6304313 Package/com.stremio.one Coolpad/C103 Android/6.0.1 Dalvik/2.1.0 (Linux; U; Android 6.0.1; C103 Build/ZIXOSOP5801711191S)',

     'Connection': 'Keep-Alive',
    'Accept-Encoding': 'utf-8'}
    url='https://v3-cinemeta.strem.io/meta/series/%s.json'%imdb_id
    logging.warning(url)
    x=get_html(url,headers=headers).json()
    
    all_d=[]
    items=x['meta']
    video_data={}
    logging.warning(items)
    rating=items.get('imdbRating','')
    imdb_id=items.get('imdb_id','')
    original_title=items['name']
    iconimage=items.get('poster','')
    fanart=items.get('background','')
    if 'runtime' in items and items['runtime']!=None:
        runtime=items['runtime'].split(' ')[0]
        video_data['duration']=int(runtime)*60
    #logging.warning(items)
    year=items.get('year','')
   
    if len(year)<4:
        year=items.get('releaseInfo','')
    description=items.get('description','Nop')
    ge=[]
    genres=items.get('genres','')
    if genres:
        for itt in genres:
            ge.append(itt)
    generes=' / '.join(ge)
   
    for items in x['meta']['videos']:
        name=items['name']
        season=items['season']
        
        if str(season)!=season_pre:
            continue
        episode=items['episode']
        description=items.get('description','Nop')
        rating=items.get('imdbRating','')
        video_data['title']=name
        video_data['imdb_id']=imdb_id
        
        video_data['year']=year
        video_data['genre']=generes

        
        video_data['rating']=rating
        video_data['plot']=description
        video_data['director']=items.get('director','')
        video_data['writer']=items.get('writer','')
        video_data['mediatype']='episode'
        video_data['TVshowtitle']=original_title
        video_data['Season']=int(season)
        video_data['Episode']=int(episode)
        video_data['aired']=items.get('firstAired','')

        actors=[]
        casts=items.get('cast','')
        if casts:
            for items in casts:
                actors.append({"name": items, "role": ""})
            
        
        logging.warning(video_data)
        all_d.append(addLink( name, 'www',4, iconimage,fanart,description,video_data,imdb_id=imdb_id,actors=actors))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
def check_res(nam):
    if '4k' in nam:
          res='2160'
    elif '2160' in nam:
          res='2160'
    elif '1080' in nam:
              res='1080'
    elif '720' in nam:
          res='720'
    elif '480' in nam:
          res='480'
    elif '360' in nam:
          res='360'
    else:
          res='HD'
    return res
def collecct_sources(video_data,url):
    global all_sources,all_hash,all_error_sources
    
    
    if 'best4stremio' in url:
        try:
            if 'TVshowtitle' in video_data:
                added_data='{"params":[null,{"query":{"imdb_id":"%s","type":"movie","season":%s,"episode":%s}}],"method":"stream.find","id":1,"jsonrpc":"2.0"}'%(video_data['imdb_id'],video_data['Season'],video_data['Episode'])
            else:
                added_data='{"params":[null,{"query":{"imdb_id":"%s","type":"movie"}}],"method":"stream.find","id":1,"jsonrpc":"2.0"}'%video_data['imdb_id']
            code=(base64.b64encode(added_data.encode("utf-8"))).decode("utf-8")
            x=get_html(url%code,headers=base_header).json()
            
            for item in x['result']:
                l_hash=item['infoHash'].lower()
                if l_hash not in all_hash:
                    all_hash.append(l_hash)
                    all_sources.append((video_data['title'],item['infoHash'],'0','720','best4stremio'))
        except Exception as e:
            all_error_sources[url]=e
    elif 'torrentio' in url or 'thepiratebay' in url or 'torrentmafya' in url:
        if 'thepiratebay' in url:
            source='thepiratebay'
        elif 'torrentmafya' in url:
            source='torrentmafya'
        else:
            source='torrentio'
        try:
            if 'TVshowtitle' in video_data:
                added_data='{0}%3A{1}%3A{2}'.format(video_data['imdb_id'],video_data['Season'],video_data['Episode'])
                tv_movie='series'
            else:
                added_data=video_data['imdb_id']
                tv_movie='movie'
            x=get_html(url%(tv_movie,added_data),headers=base_header).json()
            
            for item in x['streams']:
                l_hash=item['infoHash'].lower()
                nam=item['title'].decode('utf-8')
                logging.warning(nam)
                if 'torrentmafya' in url:
                    regex='\n(.+?)B '
                    
                    s=re.compile(regex).findall(nam)
                else:
                    regex='💾(.+?)⚙️'.decode('utf-8')
                    
                    s=re.compile(regex,re.DOTALL).findall(nam)
                
                size=0
                if len(s)>0:
                    if 'torrentmafya' in url:
                        s_result=s[0]+'B'
                    else:
                        s_result=s[0]
                    size=float(s_result.replace('GB','').replace('MB','').replace(",",'').strip())
                    
                    if 'MB' in s_result:
                       size=format(size/1000)
                    size=round(size,3)
                max_size=int(Addon.getSetting("size_limit"))
              
                if size>max_size:
                    continue
                if l_hash not in all_hash:
                    all_hash.append(l_hash)
                    res=check_res(nam)
                    all_sources.append((nam,item['infoHash'],size,res,source))
        except Exception as e:
            all_error_sources[url]=e
    elif 'eztv.re' in url and 'TVshowtitle' in video_data:
            try:
                season=str(video_data['Season'])
                episode=str(video_data['Episode'])
                
                if len(episode)==1:
                  episode_n="0"+episode
                else:
                   episode_n=episode
                if len(season)==1:
                  season_n="0"+season
                else:
                  season_n=season
                x=get_html(url%(video_data['imdb_id'].replace('tt',''),'0'),headers=base_header).json()
                dev_num=1024*1024*1024
                for items in x['torrents']:
                        nam=items['filename']
                        lk=items['magnet_url']
                        l_hash=lk.split('btih:')[1]
                        if '&' in l_hash:
                            l_hash=l_hash.split('&')[0]
                        
                        if 's%se%s.'%(season_n,episode_n) not in nam.lower():
                            continue
                        
                        size=format((float(items['size_bytes'])/dev_num))
                        size=round(size,3)
                        
                        res=check_res(nam)
                        if l_hash not in all_hash:
                            all_hash.append(l_hash)
                            res=check_res(nam)
                            all_sources.append((nam,l_hash,size,res,'eztv'))
            except Exception as e:
                all_error_sources[url]=e
    elif 'movies-v2.api-fetch' in url:
        try:
            if 'TVshowtitle' in video_data:
                added_data=video_data['imdb_id']
                tv_movie='show'
            else:
                added_data=video_data['imdb_id']
                tv_movie='movie'
            x=get_html(url%(tv_movie.replace('tv','show'),imdb_id),headers=base_header).json()
            
            if 'episodes' in x:
                season=str(video_data['Season'])
                episode=str(video_data['Episode'])
                for items in x['episodes']:
                   
                    if int(season)!=int(items['season']) or int(episode)!=int(items['episode']):
                        continue
                 
                    for items2 in items['torrents']:
                        
                        link=items['torrents'][items2]['url']
                        if link==None:
                            continue
                        l_hash=link.split('btih:')[1]
                        if '&' in l_hash:
                            l_hash=l_hash.split('&')[0]
                        
                        
                        
                        if l_hash not in all_hash:
                                all_hash.append(l_hash)
                                res=check_res(items2)
                                all_sources.append((video_data['title'],l_hash,'0',res,'movies-v2'))
            else:
              dev_num=1024*1024*1024
              for items in x['torrents']['en']:
                
                
                link=x['torrents']['en'][items]['url']
                if link==None:
                    continue
                l_hash=link.split('btih:')[1]
                if '&' in l_hash:
                    l_hash=l_hash.split('&')[0]
                
                size=x['torrents']['en'][items]['size']
                try:
                     size=format(float(size)/dev_num)
                     
                except:
                    size=0
                size=round(size,3)
                if l_hash not in all_hash:
                    all_hash.append(l_hash)
                    res=check_res(items)
                    all_sources.append((video_data['title'],l_hash,size,res,'movies-v2'))
           
        except Exception as e:
                all_error_sources[url]=e
    elif 'torrentapi' in url:
        try:
            x=get_html("https://torrentapi.org/pubapi_v2.php?app_id=me&get_token=get_token",headers=base_header,timeout=10).json()
            token=x['token']
            
                      
            if 'TVshowtitle' in video_data:
                season=str(video_data['Season'])
                episode=str(video_data['Episode'])
                
                if len(episode)==1:
                  episode_n="0"+episode
                else:
                   episode_n=episode
                if len(season)==1:
                  season_n="0"+season
                else:
                  season_n=season
                itt=video_data['TVshowtitle'].replace(' ','%20')+'%20'+'s'+season_n+'e'+episode_n
            else:
                itt=video_data['title'].replace(' ','%20')+'%20'+video_data['year']
            ur=url%(video_data['imdb_id'],token,itt)
            
            y=get_html(ur,headers=base_header,timeout=10).json()
            if 'torrent_results' not in y:
                logging.warning(ur)
                logging.warning(y)
                
            for results in y['torrent_results']:
                
          
                  
               
                nam=results['title']
                size=format(float(results['size'])/(1024*1024*1024))
                size=round(size,3)
                link=results['download']
                l_hash=link.split('btih:')[1]
                if '&' in l_hash:
                    l_hash=l_hash.split('&')[0]
                    
                
               
                if l_hash not in all_hash:
                        all_hash.append(l_hash)
                        res=check_res(nam)
                        all_sources.append((video_data['title'],l_hash,size,res,'torAPI'))
        except Exception as e:
                    all_error_sources[url]=e
    elif 'stremio-yts' in url and 'TVshowtitle' not in video_data:
            x=get_html(url%video_data['imdb_id'],headers=base_header,timeout=10).json()
            logging.warning(url%video_data['imdb_id'])
            for item in x['streams']:
                l_hash=item['infoHash'].lower()
                nam=video_data['title']
                size='0'
                s_result=re.compile('Size:(.+?)$').findall(item['title'])
                if len(s_result)>0:
                    size=float(s_result[0].replace('GB','').replace('MB','').replace(",",'').strip())
                        
                    if 'MB' in s_result[0]:
                       size=format(size/1000)
                size=round(size,3)
                if l_hash not in all_hash:
                        all_hash.append(l_hash)
                        res=check_res(item['title'])
                        all_sources.append((video_data['title'],l_hash,size,res,'yts'))


ACTION_CONTEXT_MENU  = 117
ACTION_C_KEY         = 122
ACTION_BACK          = 92
ACTION_NAV_BACK =  92## Backspace action
ACTION_PARENT_DIR    = 9
ACTION_PREVIOUS_MENU = 10

class scraper(xbmcgui.WindowXMLDialog):
    
    def __new__(cls, addonID,icon):
        FILENAME='scraper.xml'
        
        
        return super(scraper, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
    def __init__(self, addonID,icon):
        
        super(scraper, self).__init__()
        self.icon=icon
        self.selected_index=9999
    def  getInfo(self,release_title):
        info =[]
       
            
        #info.video
        if any(i in release_title for i in ['x264', 'x 264', 'h264', 'h 264', 'avc']):
            info.append('AVC')
        if any(i in release_title for i in ['x265', 'x 265', 'h265', 'h 265', 'hevc']):
            info.append('HEVC')
        if any(i in release_title for i in ['xvid']):
            info.append('XVID')
        if any(i in release_title for i in ['divx']):
            info.append('DIVX')
        if any(i in release_title for i in ['mp4']):
            info.append('MP4')
        if any(i in release_title for i in ['wmv']):
            info.append('WMV')
        if any(i in release_title for i in ['mpeg']):
            info.append('MPEG')
        if any(i in release_title for i in ['remux', 'bdremux']):
            info.append('REMUX')
        if any(i in release_title for i in [' hdr ', 'hdr10', 'hdr 10']):
            info.append('HDR')
        if any(i in release_title for i in [' sdr ']):
            info.append('SDR')
        
        #info.audio
        if any(i in release_title for i in ['aac']):
            info.append('AAC')
        if any(i in release_title for i in ['dts']):
            info.append('DTS')
        if any(i in release_title for i in ['hd ma' , 'hdma']):
            info.append('HD-MA')
        if any(i in release_title for i in ['atmos']):
            info.append('ATMOS')
        if any(i in release_title for i in ['truehd', 'true hd']):
            info.append('TRUEHD')
        if any(i in release_title for i in ['ddp', 'dd+', 'eac3']):
            info.append('DD+')
        if any(i in release_title for i in [' dd ', 'dd2', 'dd5', 'dd7', ' ac3']):
            info.append('DD')
        if any(i in release_title for i in ['mp3']):
            info.append('MP3')
        if any(i in release_title for i in [' wma']):
            info.append('WMA')
        
        #info.channels
        if any(i in release_title for i in ['2 0 ', '2 0ch', '2ch']):
            info.append('2.0')
        if any(i in release_title for i in ['5 1 ', '5 1ch', '6ch']):
            info.append('5.1')
        if any(i in release_title for i in ['7 1 ', '7 1ch', '8ch']):
            info.append('7.1')
        
        #info.source 
        # no point at all with WEBRip vs WEB-DL cuz it's always labeled wrong with TV Shows 
        # WEB = WEB-DL in terms of size and quality
        if any(i in release_title for i in ['bluray' , 'blu ray' , 'bdrip', 'bd rip', 'brrip', 'br rip']):
            info.append('BLURAY')
        if any(i in release_title for i in [' web ' , 'webrip' , 'webdl', 'web rip', 'web dl']):
            info.append('WEB')
        if any(i in release_title for i in ['hdrip', 'hd rip']):
            info.append('HDRIP')
        if any(i in release_title for i in ['dvdrip', 'dvd rip']):
            info.append('DVDRIP')
        if any(i in release_title for i in ['hdtv']):
            info.append('HDTV')
        if any(i in release_title for i in ['pdtv']):
            info.append('PDTV')
        if any(i in release_title for i in [' cam ', 'camrip', 'hdcam', 'hd cam', ' ts ', 'hd ts', 'hdts', 'telesync', ' tc ', 'hd tc', 'hdtc', 'telecine', 'xbet']):
            info.append('CAM')
        if any(i in release_title for i in ['dvdscr', ' scr ', 'screener']):
            info.append('SCR')
        if any(i in release_title for i in ['korsub', ' kor ', ' hc']):
            info.append('HC')
        if any(i in release_title for i in ['blurred']):
            info.append('BLUR')
        if any(i in release_title for i in [' 3d']):
            info.append('3D')
        all_lang=['en','eng','english','rus','russian','fr','french','TrueFrench','ita','italian','italiano','castellano','spanish','swedish','dk','danish','german','nordic','exyu','chs','hindi','polish','mandarin','kor','korean','koraen','multi']
        all_lang_des=['English','English','English','Russian','Russian','French','French','French','Italiano','Italiano','Italiano','Castellano','Spanish','Swedish','Danish','Danish','German','Nordic','ExYu','Chinese','Hindi','Polish','Mandarin','Korean','Korean','Korean','Multi']
        index=0

        for itt in all_lang:
            if ' '+itt+' ' in release_title.lower():
                if all_lang_des[index] not in info:
                    info.append('[COLOR lightblue]'+all_lang_des[index]+'[/COLOR]')
            index+=1
            
        
                
        return info
    def monitor_state(self):
        global string_dp2,all_sources_final,still_scraping,prect
        all_liz_items=[]
        self.list = self.getControl(2)
        
        start_time=time.time()
   
        
        elapsed_time = 0
        while still_scraping:
            elapsed_time = time.time() - start_time
            self.getControl(202).setLabel(string_dp2+' ' +time.strftime("%H:%M:%S", time.gmtime(elapsed_time)))
            
            self.getControl(6).setPercent(prect)
            time.sleep(0.2)
        self.getControl(202).setLabel(string_dp2)
        
        if len(all_sources_final)>0:
            for title,l_hash,size,res,source in all_sources_final:
                liz = xbmcgui.ListItem(title)
                info=self.getInfo(title)
                fixed_title=title.encode('ascii', errors='ignore').decode('ascii', errors='ignore')
                if '\n' in fixed_title:
                    fixed_title=fixed_title.split('\n')[0]
                liz.setProperty('title',source+'|[COLOR yellow]'+fixed_title+'[/COLOR]\n[COLOR lime]['+res +'][/COLOR] | [COLOR pink][B][I]'+str(size)+"GB [/B][/I][/COLOR]| [COLOR khaki]"+'|'.join(info)+'[/COLOR]')
                all_liz_items.append(liz)
            self.list.addItems(all_liz_items)
            self.setFocus(self.list)
    def onInit(self):
        global all_alive,still_scraping,all_sources_final
        
        self.getControl(1).setImage(self.icon)
        thread=[]

        thread.append(Thread(self.monitor_state))

        thread[len(thread)-1].start()
    def onAction(self, action):  
       
        actionId = action.getId()
       
        
            
        if actionId in [ACTION_CONTEXT_MENU, ACTION_C_KEY]:
            

            self.close()

        if actionId in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK,ACTION_NAV_BACK]:
            
            self.close()

    
    def onClick(self, controlId):
        
        
        if controlId != 3001:
            
            index = self.list.getSelectedPosition()        
            
            try:    
                self.params = index
                logging.warning('Clicked:'+str(controlId)+':'+str(index))
            except:
                self.params = None
            
            self.selected_index=self.params
            self.close()
            #return self.params
        else:
            logging.warning('Click close')
            self.selected_index=9999
            self.close()
def stop_play():
    
    if KODI_VERSION==18:
        return 'forceexit'
    else:
        return 'return'

ACTION_LEFT  = 1
ACTION_RIGHT = 2
ACTION_UP    = 3
ACTION_DOWN  = 4
domain_s='https://'
COLOR1         = 'gold'
COLOR2         = 'white'
# Primary menu items   / %s is the menu item and is required
THEME3         = '[COLOR '+COLOR1+']%s[/COLOR]'
# Build Names          / %s is the menu item and is required
THEME2         = '[COLOR '+COLOR2+']%s[/COLOR]'
def contact(title='',msg=""):
    class MyWindow(xbmcgui.WindowXMLDialog):
        def __init__(self, *args, **kwargs):
            self.title = THEME3 % kwargs["title"]
            self.image = kwargs["image"]
            self.fanart = kwargs["fanart"]
            self.msg = THEME2 % kwargs["msg"]

        def onInit(self):
            self.fanartimage = 101
            self.titlebox = 102
            self.imagecontrol = 103
            self.textbox = 104
            self.scrollcontrol = 105
            self.button = 199
            self.showdialog()

        def showdialog(self):
            #self.getControl(self.imagecontrol).setImage(self.image)
            self.getControl(self.fanartimage).setImage(self.fanart)
            self.getControl(self.fanartimage).setColorDiffuse('9FFFFFFF')
            self.getControl(self.textbox).setText(self.msg)
            self.getControl(self.titlebox).setLabel(self.title)
            addonPath = xbmc.translatePath(Addon.getAddonInfo("path"))
            source_dir = os.path.join(addonPath, 'resources', 'blink.mp4')
            xbmc.Player().play(source_dir, windowed=True)
    
        
            
            self.setFocusId(self.button)
            
        def onAction(self,action):
            if   action == ACTION_PREVIOUS_MENU: 
                xbmc.Player().stop()
                self.close()
            elif action == ACTION_NAV_BACK: 
                xbmc.Player().stop()
                self.close()
            
    cw = MyWindow( "Contact.xml" , Addon.getAddonInfo('path'), 'DefaultSkin', title=title, fanart=' ', image='https://media.tenor.com/images/01a72c6c370d8743e3c1b5864866e093/tenor.gif', msg=msg)
    cw.doModal()
    del cw
def show_updates(force=False):
    
    
    #from shutil import copyfile
    version = Addon.getAddonInfo('version')
    ms=False
    if not os.path.exists(os.path.join(user_dataDir, 'version.txt')):
        ms=True
    else:
        file = open(os.path.join(user_dataDir, 'version.txt'), 'r') 
        file_data= file.readlines()
        file.close()
        if version not in file_data:
          ms=True
    if force==True:
        ms=True
    if ms:
        current_folder = os.path.dirname(os.path.realpath(__file__))
        change_log=os.path.join(current_folder,'changelog.txt')
        file = open(change_log, 'r') 
        news= file.read()
        file.close()
        
        
        contact(title="Welcome to version -"+version ,msg=news)
        file = open(os.path.join(user_dataDir, 'version.txt'), 'w') 
        file.write(version)
        file.close()
        ClearCache()
def put_window(icon,video_data):
    global all_sources_final,playback_url,still_in_window,original_url
    try:
        menu2 = scraper(sys.argv[0],icon)
        
      
        if 'TVshowtitle' in video_data:
            season=video_data['Season']
            episode=video_data['Episode']
            tv_movie='tv'
        else:
            season='0'
            episode='0'
            tv_movie='movie'
       
        
        menu2.doModal()
        index=menu2.selected_index
        del menu2
        logging.warning('index:'+str(index))
        if index==9999:
            s=stop_play()
            still_in_window=False
            if s=='forceexit':
                playback_url= 'www'
            else:
                playback_url= 'www'
            return 0
       
        thread=[]
        thread.append(Thread(show_new_window,tv_movie, video_data['imdb_id'], season, episode))
        #show_new_window(tv_movie, video_data['imdb_id'], season, episode)
        thread[0].start()
        
        title,l_hash,size,res,source =all_sources_final[index]
        logging.warning('l_hash:'+l_hash)
        url='magnet:?xt=urn:btih:%s&dn=%s'%(l_hash,(source))
        #import resolveurl
        logging.warning('Resolving::')
        logging.warning(url)
        #from resources.lib.modules import real_debrid
        #rd = real_debrid.RealDebrid()
        
        logging.warning('resolve_magnet:'+l_hash)
        logging.warning(source)
        if 'RD_' in source:
            original_url='RD___'+url
            logging.warning('In RD')
            from resources.lib.debrid.realdebrid import RealDebrid as debrid_function
        elif 'AD_' in source:
            original_url='AD___'+url
            from resources.lib.debrid.alldebrid import AllDebrid as debrid_function
        elif 'PM_' in source:
            original_url='PM___'+url
            logging.warning('In PM_')
            from resources.lib.debrid.premiumize import Premiumize as debrid_function
        if 'TVshowtitle' not in video_data:
            logging.warning('Movie link')
            season=None
            episode=None
        
        playback_url = debrid_function().resolve_magnet(url, l_hash, season, episode, title)
        still_in_window=False
        return playback_url
    except:
        still_in_window=False
def get_sources_cached(video_data):
    global all_sources,all_hash,all_error_sources,prect
    global string_dp2,still_scraping,all_sources_final,playback_url
    try:
        logging.warning('1')
        if KODI_VERSION<=18:
            xbmc_tranlate_path=xbmc.translatePath
        else:
            xbmc_tranlate_path=xbmcvfs.translatePath
        thread=[]
        
        count=1
        
        for items in sources_addr:
            thread.append(Thread(collecct_sources,video_data,items))
            thread[len(thread)-1].setName('Scraper no:'+str(count))
            count+=1
            #thread[len(thread)-1].start()
            #collecct_sources(video_data,items)
        
        start_time=time.time()
        addonPath = xbmc_tranlate_path(Addon.getAddonInfo("path"))
        source_dir = os.path.join(addonPath, 'resources', 'sources')
        import pkgutil
        
        original_title=video_data.get('original_title',name)
        tv_movie='movie'
        season='0'
        episode='0'
        season_n='0'
        episode_n='0'
        show_original_year=video_data['year']
        id=video_data['imdb_id']
        if 'Season' in video_data:
            season=str(video_data['Season'])
            episode=str(video_data['Episode'])
            tv_movie='tv'
            if len(season)==1:
              season_n="0"+season
            else:
              season_n=season
            if len(episode)==1:
              episode_n="0"+episode
            else:
              episode_n=episode
        all_sources_sh=[]
        for loader, items, is_pkg in pkgutil.walk_packages([source_dir]):
            if is_pkg: 
                continue
            
           
            module = loader.find_module(items).load_module(items)
            impmodule = module
            
            
            impmodule.stop_all=0
            impmodule.global_var=[]
            thread.append(Thread(impmodule.get_links,tv_movie,original_title,season_n,episode_n,season,episode,show_original_year,id))
            thread[len(thread)-1].setName(items.replace('.py',''))
            all_sources_sh.append((items,impmodule))
        for tr in thread:
            tr.start()
        max_time=int(Addon.getSetting("time_s"))
        while 1:
            num_live=0

            elapsed_time = time.time() - start_time

            num_live=0
            string_dp=''
            
            still_alive=0
            string_dp3=[]
            all_alive={}
            count_alive=0
            count_dead=0
            for yy in range(0,len(thread)):
                all_alive[thread[yy].name]=thread[yy].is_alive()
                

                if not thread[yy].is_alive():
                  num_live=num_live+1
                  count_dead+=1
                  
             
                else:
                  count_alive+=1
                  string_dp3.append(thread[yy].name)
                  
                  still_alive=1
            if len(string_dp3)<3:
                string_dp2=','.join(string_dp3)
            else:
                string_dp2='S: '+str(len(thread)-count_dead)
            prect=int(100-(100*(float(count_alive)/len(thread))))
            if elapsed_time>max_time:
                break
            if still_alive==0:
                
                break
        for threads in thread:
                
            if threads.is_alive():
                 
                 
                 try:
                    thread._Thread__stop()
                 except:
                    pass
        for thread in threading.enumerate():
          string_dp2='Closing threads: '+thread.getName()
          if (trd_alive(thread)):
             alive=1
             try:
                thread._Thread__stop()
             except:
                pass
        f_result={}
        for name1,items in all_sources_sh:
                f_result[name1]={}
                f_result[name1]['links']=items.global_var
        for data in f_result:
            for links_in in f_result[data]['links']:
                name1,links,server,res=links_in
                lk=links
                name1_t=name1.replace("'",'').replace('%20',' ').replace(' & ','').replace(' and ','').replace('_','.').replace('%3A','.').replace('%3a','.').replace(':','').replace('-','.').replace('[','(').replace(']',')').replace('  ','.').replace(' ','.').replace('....','.').replace('...','.').replace('..','.').replace("'",'').strip().lower()
                t_name=video_data['original_title'].replace("'",'').replace(' & ','').replace(' and ','').replace('_','.').replace('%3A','.').replace('%3a','.').replace(':','').replace('-','.').replace('[','(').replace(']',')').replace('  ','.').replace(' ','.').replace('....','.').replace('...','.').replace('..','.').replace("'",'').strip().lower()
                if t_name not in name1_t:
                    logging.warning('Rejected name:')
                    logging.warning(video_data['original_title'].lower().replace('.','').replace(' ',''))
                    logging.warning(name1.lower().replace('.','').replace(' ',''))
                    continue
                if 'TVshowtitle' in video_data:
                    c_name=name1_t
                    reject=True
                    season=video_data['Season']
                    episode=video_data['Episode']
                    if 's%se%s.'%(season_n,episode_n) in c_name or 's%se%s###'%(season_n,episode_n) in c_name+'###'  or 's%se%s###'%(season,episode) in c_name+'###' or 's%se%s.'%(season,episode) in c_name:
                        
                        reject=False
                    elif 'season' in c_name:
                      
                      if 'season.%s.'%season not in c_name.lower() and 'season.%s$$$'%season not in (c_name.lower()+'$$$') and 'season.%s$$$'%season_n not in (c_name.lower()+'$$$') and 'season.%s.'%season_n not in c_name.lower() and 'season %s'%season_n not in c_name and 'season %s '%season not in c_name:
                        logging.warning('r3')
                        logging.warning(c_name)
                        reject=True
                    elif '.s%s.'%season_n in c_name:
                        
                        reject=False
                    if reject:
                        continue
                        
                if 'magnet:' not in links:
                    continue
                l_hash=links.split('btih:')
                if len(l_hash)>0:
                   
                   l_hash=l_hash[1]
                else:
                    logging.warning('Bad hash:'+links)
                    continue
                if '&' in l_hash:
                    l_hash=l_hash.split('&')[0]
                
                if l_hash not in all_hash:
                    all_hash.append(l_hash)
                    
                    all_sources.append((name1,l_hash,server,res,data))
        all_mag={}
        counter_hash=0
        page_index=0
        all_mag[page_index]=[]
        from resources.lib.modules import debridcheck
        DBCheck = debridcheck.DebridCheck()
       
        elapsed_time = time.time() - start_time
        string_dp2='Checking cached torrents: '+str(len(all_hash))+', '
        
        cachedRDHashes, cachedADHashes, cachedPMHashes, cachedDLHashes = DBCheck.run(all_hash)

        all_hash_checked=cachedRDHashes+cachedADHashes+cachedPMHashes
        
    
        if len(all_hash_checked)==0:
            xbmcgui.Dialog().ok('Blink','No sources found')
        string_dp2='Sorting'
        f_titles=[]
        all_2160=[]
        all_1080=[]
        all_720=[]
        all_rest=[]
        for title,l_hash,size,res,source in all_sources:
            
            if '2160' in res or '4k' in res.lower():
                all_2160.append((title,l_hash,float(size),res,source))
            elif '1080' in res:
                all_1080.append((title,l_hash,float(size),res,source))
            elif '720' in res:
                all_720.append((title,l_hash,float(size),res,source))
            else:
                all_rest.append((title,l_hash,float(size),res,source))
        all_2160=sorted(all_2160, key=lambda x: x[2], reverse=True)
        all_1080=sorted(all_1080, key=lambda x: x[2], reverse=True)
        all_720=sorted(all_720, key=lambda x: x[2], reverse=True)
        all_rest=sorted(all_rest, key=lambda x: x[2], reverse=True)
        all_sources_final_pre=all_2160+all_1080+all_720+all_rest
        
        still_scraping=False
        logging.warning('Here')
        all_2160=[]
        all_1080=[]
        all_720=[]
        all_rest=[]
        all_sources_final=[]
        counter=1
        for title,l_hash,size,res,source in all_sources_final_pre:
            if l_hash in all_hash_checked:
                if l_hash in cachedRDHashes:
                    source='[COLOR green]RD_[/COLOR]'+source
                elif l_hash in cachedADHashes:
                    source='[COLOR blue]AD_[/COLOR]'+source
                elif l_hash in cachedPMHashes:
                    source='[COLOR yellow]PM_[/COLOR]'+source
                    
                if '2160' in res or '4k' in res.lower():
                    all_2160.append((title,l_hash,float(size),res,source))
                elif '1080' in res:
                    all_1080.append((title,l_hash,float(size),res,source))
                elif '720' in res:
                    all_720.append((title,l_hash,float(size),res,source))
                else:
                    all_rest.append((title,l_hash,float(size),res,source))
                all_sources_final.append((title,l_hash,round(size,2),res,'[COLOR gold]'+str(counter)+'.[/COLOR] '+source))
                counter+=1
        all_sources_final_pre=all_2160+all_1080+all_720+all_rest
        string_dp2="4K: [COLOR yellow]%s[/COLOR] 1080: [COLOR khaki]%s[/COLOR] 720: [COLOR gold]%s[/COLOR] 480: [COLOR silver]%s[/COLOR], Total: %s"%(str(len(all_2160)),str(len(all_1080)),str(len(all_720)),str(len(all_rest)),str(len(all_sources_final_pre)))
        return all_sources_final,string_dp2
    except Exception as e:
        import linecache
        still_scraping=False
        exc_type, exc_obj, tb = sys.exc_info()
        f = tb.tb_frame
        lineno = tb.tb_lineno
        filename = f.f_code.co_filename
        linecache.checkcache(filename)
        line = linecache.getline(filename, lineno, f.f_globals)
        xbmc.executebuiltin((u'Notification(%s,%s)' % ('Blink', 'Line:'+str(lineno)+' E:'+str(e))).encode('utf-8'))
        logging.warning('ERROR IN Scraping :'+str(lineno))
        logging.warning('inline:'+line)
        logging.warning(e)

        logging.warning('BAD Trailer play')
        return [],''
def get_more_meta(id,tv_movie,tvdb_id):
    user = 'cf0ebcc2f7b824bd04cf3a318f15c17d'

    headers = {'api-key': '9f846e7ec1ea94fad5d8a431d1d26b43'}

    headers.update({'client-key': user})
    if tv_movie=='tv':
        m_type='tv'
    else:
        m_type='movies'
    f_id=id
    if tv_movie=='tv':
        f_id=tvdb_id
    art=get_html('http://webservice.fanart.tv/v3/%s/%s'%(m_type,f_id),headers=headers).json()
    
    return art
    
class player_window(xbmcgui.WindowXMLDialog):
    def __new__(cls, addonID,id,tv_movie,season,episode):
        
        
        FILENAME='play_window.xml'
        
        return super(player_window, cls).__new__(cls, FILENAME,Addon.getAddonInfo('path'), 'DefaultSkin')
        

    def __init__(self, addonID,id,tv_movie,season,episode):
        super(player_window, self).__init__()
        self.tv_movie=tv_movie
        url='https://'+'api.themoviedb.org/3/find/%s?api_key=34142515d9d23817496eeb4ff1d223d0&external_source=imdb_id'%(id)
        html_im=get_html(url).json()
        self.id=id
         
        if season=='0':
             if len(html_im['movie_results'])>0:
                self.id=str(html_im['movie_results'][0]['id'])
        else:
            if len(html_im['tv_results'])>0:
                self.id=str(html_im['tv_results'][0]['id'])
                    
        
        self.poster=1
        self.label=5
        self.close_now=False
        self.playbutton=5003
    def onAction(self, action):
        
        
        actionId = action.getId()

        if actionId in [ACTION_CONTEXT_MENU, ACTION_C_KEY]:
            self.close_now=True
            return self.close()

        if actionId in [ACTION_PARENT_DIR, ACTION_PREVIOUS_MENU, ACTION_BACK]:
            self.close_now=True
            return self.close()
    def get_img_ch(self,tv_movie,id):
        url='https://api.themoviedb.org/3/%s/%s?api_key=34142515d9d23817496eeb4ff1d223d0&include_image_language=ru,null&append_to_response=images,external_ids'%(self.tv_movie,self.id)
       
        html=get_html(url).json()
        return html
    def get_img(self):
        from resources.lib.modules import cache
        import random
        self.html=cache.get(self.get_img_ch, 999,self.tv_movie,self.id,table='pages')
        
        fan='https://image.tmdb.org/t/p/original/'+self.html['backdrop_path']
       
       
        self.getControl(self.poster).setImage(fan)
        
        try:
          tvdb_id=str(self.html['external_ids']['tvdb_id'])
        except:
         tvdb_id=''
        logging.warning('tvdb::'+tvdb_id)
        all_n_fan=[]
        all_banner=[]
        try:
            
            
            full_art= cache.get(get_more_meta, 72, self.id,self.tv_movie,tvdb_id, table='pages') 
            
            
            if self.tv_movie=='tv':
                logo=full_art['hdtvlogo']
                if len(logo)>0:
                   
                    all_logo=[]
                    for itt in logo:
                       if itt['lang']=='en':
                        all_logo.append(itt['url'])
                    random.shuffle(all_logo)
                    self.getControl(5002).setImage(all_logo[0])
                
                
                for itt in full_art['showbackground']:
                   if itt['lang']=='en':
                    all_n_fan.append(itt['url'])
                for itt in full_art['tvbanner']:
                   if itt['lang']=='en':
                    all_banner.append(itt['url'])
            else:
                logo=full_art['hdmovielogo']
                if len(logo)>0:
                    all_logo=[]
                    for itt in logo:
                      if itt['lang']=='en':
                        all_logo.append(itt['url'])
                    random.shuffle(all_logo)
                    self.getControl(5002).setImage(all_logo[0])
                
                if 'moviebackground' in full_art:
                    for itt in full_art['moviebackground']:
                       if itt['lang']=='en':
                        all_n_fan.append(itt['url'])
                for itt in full_art['moviebanner']:
                   if itt['lang']=='en':
                    all_banner.append(itt['url'])
        except Exception as e:
            logging.warning('Fanart Err:'+str(e))
    def onInit(self):
        global play_status,play_status_rd_ext,break_window
        
        thread=[]
        thread.append(Thread(self.get_img))
        thread[len(thread)-1].setName('background_task')
        
        for td in thread:
            td.start()
            
        
        timeout=0
        start_time=time.time()
        while timeout<2000:
            timeout+=1
            if self.close_now:
                break
            elapsed_time = time.time() - start_time
            
            ext=play_status_rd_ext.play_status_rd
            try:
               ext=play_status_rd_ext.play_status_rd
            except :
               ext=''
            self.getControl(self.label).setLabel('Wait for playback'+': '+time.strftime("%H:%M:%S", time.gmtime(elapsed_time))+', '+play_status+ext)
            
         
            if not xbmc.getCondVisibility('Window.IsActive(busydialog)'):
                        
                break
            if xbmc.Player().isPlaying():
                    
                try:
                    vidtime = xbmc.Player().getTime()
                    #if vidtime>10:
                    #    logging.warning('Vid time break:'+str(vidtime))
                        
                        #break
                except:
                    pass
            
                
            if break_window:
                break
            xbmc.sleep(100)
        
        return self.close()
def show_new_window(tv_movie,id,season,episode):
    global break_window,break_window_rd,play_status_rd_ext
    from resources.lib.debrid import realdebrid 

    play_status_rd_ext=realdebrid
    menu = player_window('plugin.video.blink', id,tv_movie,season,episode)
    menu.doModal()

    del menu
    
    break_window=True
    break_window_rd=True
    logging.warning('break_window2:'+str(break_window))        
def store_watched(video_data,url,iconimage,fanart,description):
    if 'original_title' in video_data:
        original_title=video_data['original_title']
    elif 'original_name' in video_data:
        original_title=video_data['original_name']
    else:
        original_title=video_data['title']
    
    
    heb_name=video_data['title']
    show_original_year=video_data['year']
    id=video_data['imdb_id']
    season='0'
    episode='0'
    
    
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
    if 'TVshowtitle' in video_data:
       season=video_data['Season']
       episode=video_data['Episode']
       table_name='lastlinktv'
    else:
       table_name='lastlinkmovie'
    
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""o_name TEXT,""name TEXT, ""url TEXT, ""iconimage TEXT, ""fanart TEXT,""description TEXT,""data TEXT,""season TEXT,""episode TEXT,""original_title TEXT,""saved_name TEXT,""heb_name TEXT,""show_original_year TEXT,""eng_name TEXT,""isr TEXT,""prev_name TEXT,""id TEXT);"%table_name)
    dbcur.execute("CREATE TABLE IF NOT EXISTS %s ( ""name TEXT, ""url TEXT, ""icon TEXT, ""image TEXT, ""plot TEXT, ""year TEXT, ""original_title TEXT, ""season TEXT, ""episode TEXT, ""id TEXT, ""eng_name TEXT, ""show_original_year TEXT, ""heb_name TEXT , ""isr TEXT, ""type TEXT);" % 'Lastepisode')
    
    dbcon.commit()
    dbcur.execute("DELETE FROM %s"%table_name)
             
    match = dbcur.fetchone()
     
    if match==None:
        dbcur.execute("INSERT INTO %s Values ('f_name','%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s','%s');" %  (table_name,' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' ',' '))
        dbcon.commit()
        try:
        
            try:
               if KODI_VERSION<=18:
                    desk=description.replace("'","%27").encode('utf-8')
               else:
                    desk=description.replace("'","%27")
            except:
                desk=''
            dbcur.execute("UPDATE %s SET name='%s',url='%s',iconimage='%s',fanart='%s',description='%s',data='%s',season='%s',episode='%s',original_title='%s',saved_name='%s',heb_name='%s',show_original_year='%s',eng_name='%s',isr='%s',prev_name='%s',id='%s' WHERE o_name = 'f_name'"%(table_name,name.replace("'","%27"),base64.b64encode(url.encode("utf-8")).decode("utf-8") ,iconimage,fanart,desk,str(show_original_year).replace("'","%27"),season,episode,original_title.replace("'","%27"),original_title.replace("'","%27"),original_title.replace("'","%27"),show_original_year,original_title.replace("'","%27").replace("'","%27"),'0',original_title.replace("'","%27"),id))
            dbcon.commit()
        except Exception as e:
            logging.warning('Error in Saving Last:'+str(e))
            pass
    
    if table_name=='lastlinktv':
        tv_movie='tv'
    else:
        tv_movie='movie'
    dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s' and type='%s'"%(original_title.replace("'","%27"),tv_movie))
    match = dbcur.fetchone()
    
    dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s' and type='%s'"%(original_title.replace("'","%27").replace(" ","%20"),tv_movie))
    match_space = dbcur.fetchone()
    if match==None and match_space!=None:
        dbcur.execute("UPDATE Lastepisode SET original_title='%s' WHERE original_title = '%s' and type='%s'"%(original_title.replace("'","%27"),original_title.replace("'","%27").replace(" ","%20"),tv_movie))
        dbcon.commit()
        dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s' and type='%s'"%(original_title.replace("'","%27"),tv_movie))
        match = dbcur.fetchone()
   
    if match==None:
      try:
        dbcur.execute("INSERT INTO Lastepisode Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (heb_name.replace("'","%27"),url.replace("'","%27"),iconimage,fanart,description.replace("'","%27"),show_original_year,original_title.replace("'","%27"),season,episode,id,original_title.replace("'","%27"),show_original_year,heb_name.replace("'","%27"),'0',tv_movie))
      except:
        try:
            dbcur.execute("INSERT INTO Lastepisode Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (heb_name.replace("'","%27"),url.replace("'","%27"),iconimage,fanart,description.replace("'","%27"),show_original_year,original_title.replace("'","%27"),season,episode,id,original_title.replace("'","%27"),show_original_year,heb_name.replace("'","%27"),'0',tv_movie))
        except:
            
            dbcur.execute("INSERT INTO Lastepisode Values ('%s', '%s', '%s', '%s','%s', '%s', '%s', '%s', '%s', '%s', '%s', '%s','%s','%s','%s');" %  (heb_name.replace("'","%27"),url.replace("'","%27"),iconimage,fanart,' ',show_original_year,original_title.replace("'","%27"),season,episode,id,original_title.replace("'","%27"),show_original_year,heb_name.replace("'","%27"),'0',tv_movie))
      dbcon.commit()
     
    else:
      dbcur.execute("SELECT * FROM Lastepisode WHERE original_title = '%s' and type='%s' and season='%s' and episode='%s'"%(original_title.replace("'","%27"),tv_movie,season,episode))

      match = dbcur.fetchone()
     
      if match==None:
        
        dbcur.execute("UPDATE Lastepisode SET season='%s',episode='%s',image='%s',heb_name='%s' WHERE original_title = '%s' and type='%s'"%(season,episode,fanart,heb_name.replace("'","%27"),original_title.replace("'","%27"),tv_movie))
        dbcon.commit()
            
    dbcur.close()
    dbcon.close()
def get_sources(video_data,icon,fanart,description,just_play=False):
    global all_sources_final,still_scraping,still_in_window,original_url
    from resources.lib.modules import cache
    video_data=json.loads(video_data)
    if not just_play:
        if 'tt' not in video_data['imdb_id']:
            
            
            if 'TVshowtitle' not in video_data:
                url='https://api.themoviedb.org/3/movie/%s?api_key=34142515d9d23817496eeb4ff1d223d0&include_image_language=ru,null&append_to_response=images,external_ids'%(video_data['imdb_id'])
                logging.warning(url)
                html_im=get_html(url,headers=base_header,verify=False).json()
                logging.warning(html_im)
                if len(html_im['external_ids']['imdb_id'])>0:
                    id=str(html_im['external_ids']['imdb_id'])
            else:
                url='https://api.themoviedb.org/3/tv/%s?api_key=34142515d9d23817496eeb4ff1d223d0&include_image_language=ru,null&append_to_response=images,external_ids'%(video_data['imdb_id'])
                html_im=get_html(url,headers=base_header,verify=False).json()
                if len(html_im['external_ids']['imdb_id'])>0:
                    id=str(html_im['external_ids']['imdb_id'])
            video_data['title']=video_data['original_title']
            video_data['imdb_id']=id
        
        still_scraping=True
        string_dp2='Ready Choose one'
        all_sources_final=[]
        logging.warning('01')
        
        still_in_window=True
        thread2=[]
        thread2.append(Thread(put_window,icon,video_data))
        thread2[len(thread2)-1].start()
        logging.warning('02')
        #all_sources_final,string_dp2=get_sources_cached(video_data)
        all_sources_final,string_dp2=cache.get(get_sources_cached, 72,video_data,table='pages')
        still_scraping=False
        '''
        ret=xbmcgui.Dialog().select("Choose", f_titles)
        if ret!=-1:
            
              selected_genre=f_titles[ret]
            
        else:
            return 0
        
        logging.warning(all_sources)
        logging.warning('Errors:')
        logging.warning(all_error_sources)
        logging.warning('Final:')
        logging.warning(all_hash_checked)
        '''
        while 1:
            if not still_in_window:
                break
            time.sleep(0.2)
    
    listItem = xbmcgui.ListItem(path=playback_url)
    listItem.setInfo(type='Video', infoLabels=video_data)
    try:
        listItem.setUniqueIDs({ 'imdb': video_data['imdb_id']}, "imdb")
    except:
        pass
    ok=xbmcplugin.setResolvedUrl(handle=int(sys.argv[1]), succeeded=True, listitem=listItem)#play video
    if len(original_url)>2:
        store_watched(video_data,original_url,icon,fanart,description)
def ClearCache():
    from resources.lib.modules import cache
    logging.warning('Clear')
    cache.clear(['cookies', 'pages','posters'])
    xbmc.executebuiltin((u'Notification(%s,%s)' % (Addon.getAddonInfo('name'),  "Cleared")))
def ClearRD():
    try:
        resuaddon=xbmcaddon.Addon('script.module.resolveurl')
        resuaddon.setSetting('RealDebridResolver_client_id','')
        resuaddon.setSetting('RealDebridResolver_token','')
        resuaddon.setSetting('RealDebridResolver_client_secret','')
        resuaddon.setSetting('RealDebridResolver_refresh','')
    
    except Exception as e:
        resuaddon=None
        pass
    Addon.setSetting('rd.client_id','')
    Addon.setSetting('rd.auth','')
    Addon.setSetting('rd.refresh','')
    Addon.setSetting('rd.secret','')
    xbmc.executebuiltin((u'Notification(%s,%s)' % (Addon.getAddonInfo('name'), 'Cleared')))
def get_html_g(tv_movie):
    if tv_movie=='tv':
        url_g='https://api.themoviedb.org/3/genre/tv/list?api_key=34142515d9d23817496eeb4ff1d223d0&language='+lang
        html_g=get_html(url_g).json()
         
    else:
        url_g='https://api.themoviedb.org/3/genre/movie/list?api_key=34142515d9d23817496eeb4ff1d223d0&language='+lang
        html_g=get_html(url_g).json()
    
    return html_g
             
def tmdb_data(url,page,description,video_data):
    if page=='0':
        page=1
    from resources.lib.modules import cache
    from resources.lib.modules.tmdbv3api import TMDb
    tmdb = TMDb()
    tmdb.api_key = '34142515d9d23817496eeb4ff1d223d0'
    tmdb.language = lang
    tmdb.debug = True
    all_d=[]
    if description=='movie':
        tv_movie='movie'
        html_g=cache.get(get_html_g,72,'movie',table='pages')
        selected_genre=None
        if '$$$' in url:
            selected_genre=url.split('$$$')[0]
            url=url.split('$$$')[1]
        if url=='Top' or url=='Ratings' or url=='Search':
            
            from resources.lib.modules.tmdbv3api import Movie
            movie = Movie()
            if url=='Top':
                popular = movie.popular(page=page)
            elif url=='Ratings':
                popular = movie.top_rated(page=page)
            elif url=='Search':
                if not selected_genre:
                    selected_genre=''
                    keyboard = xbmc.Keyboard(selected_genre, 'Enter Search')
                    keyboard.doModal()
                    if keyboard.isConfirmed() :
                           selected_genre = que(keyboard.getText().replace("'",""))
                           if selected_genre=='':
                            sys.exit()
                popular = movie.search(selected_genre,page=page)
            for p in popular:
                video_data={}
        
        
                video_data['title']=p.title
                video_data['imdb_id']=str(p.id)
                try:
                    video_data['year']=str(p.release_date.split("-")[0]) 
                except:
                    video_data['year']='0'
                    pass
                genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
                try:genere = u' / '.join([genres_list[x] for x in p.genre_ids])
                except:genere=''
                 
                video_data['genre']=genere
                
                
                video_data['rating']=p.vote_average
                video_data['plot']=p.overview
                video_data['original_title']=p.original_title
                iconimage=base_icon_movies
                fanart=base_image_movies
                if p.poster_path:
                    iconimage='https://image.tmdb.org/t/p/original/'+p.poster_path
                if p.backdrop_path:
                    fanart='https://image.tmdb.org/t/p/original/'+p.backdrop_path
                description=p.overview
                
                all_d.append(addLink( video_data['title'], 'www',4, iconimage,fanart,description,video_data,imdb_id=p.id))
            if url=='Search':
                url=str(selected_genre)+'$$$'+url
        elif url=='Genres':
            from resources.lib.modules.tmdbv3api import Genre
            genre=Genre()
            all_id=[]
            all_n=[]
            for items in genre.movie_list():
                all_id.append(items['id'])
                all_n.append(items['name'])
            if not selected_genre:
                ret=xbmcgui.Dialog().select("Choose", all_n)
                if ret!=-1:
                    
                      selected_genre=all_id[ret]
                    
                else:
                    return 0
            from resources.lib.modules.tmdbv3api import Discover
            discover=Discover()
            movies = discover.discover_movies({
                'with_genres': int(selected_genre),
                'sort_by': 'popularity.desc',
                'page':page
            })
            for item in movies:
                video_data={}
        
        
                video_data['title']=item['title']
                video_data['imdb_id']=str(item['id'])
                try:
                    video_data['year']=str(item['release_date'].split("-")[0])
                except:
                    video_data['year']='0'
                genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
                try:genere = u' / '.join([genres_list[x] for x in item['genre_ids']])
                except:genere=''
                 
                video_data['genre']=genere
                
                
                video_data['rating']=item['vote_average']
                video_data['plot']=item['overview']
                video_data['original_title']=item['original_title']
                iconimage=base_icon_movies
                fanart=base_image_movies
                if item['poster_path']:
                    iconimage='https://image.tmdb.org/t/p/original/'+item['poster_path']
                if item['backdrop_path']:
                    fanart='https://image.tmdb.org/t/p/original/'+item['backdrop_path']
                description=item['overview']
                all_d.append(addLink( video_data['title'], 'www',4, iconimage,fanart,description,video_data,imdb_id=item['id']))
            url=str(selected_genre)+'$$$'+url
        elif url=='Years':
            
            if not selected_genre:
                all_years=[]
                import datetime
                all_d=[]
                now = datetime.datetime.now()
                for year in range(now.year,1970,-1):
                     all_years.append(str(year))
                ret= xbmcgui.Dialog().select("Choose", all_years)
                if ret!=-1:
                    
                      selected_genre=all_years[ret]
                    
                else:
                    return 0
            from resources.lib.modules.tmdbv3api import Discover
            discover=Discover()
            movies = discover.discover_movies({
                'primary_release_year': int(selected_genre),
                'sort_by': 'popularity.desc',
                'page':page
            })
            for item in movies:
                video_data={}
        
        
                video_data['title']=item['title']
                video_data['imdb_id']=str(item['id'])
                try:
                    video_data['year']=str(item['release_date'].split("-")[0])
                except:
                    video_data['year']='0'
                genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
                try:genere = u' / '.join([genres_list[x] for x in item['genre_ids']])
                except:genere=''
                 
                video_data['genre']=genere
                
                
                video_data['rating']=item['vote_average']
                video_data['plot']=item['overview']
                video_data['original_title']=item['original_title']
                iconimage=base_icon_movies
                fanart=base_image_movies
                if item['poster_path']:
                    iconimage='https://image.tmdb.org/t/p/original/'+item['poster_path']
                if item['backdrop_path']:
                    fanart='https://image.tmdb.org/t/p/original/'+item['backdrop_path']
                description=item['overview']
                all_d.append(addLink( video_data['title'], 'www',4, iconimage,fanart,description,video_data,imdb_id=item['id']))
            url=str(selected_genre)+'$$$'+url
    else:
        html_g=cache.get(get_html_g,72,'tv',table='pages')
        selected_genre=None
        tv_movie='tv'
        if '$$$' in url:
            selected_genre=url.split('$$$')[0]
            url=url.split('$$$')[1]
        if url=='Top' or url=='Ratings' or url=='Search':
            
            from resources.lib.modules.tmdbv3api import TV
            tv = TV()
            if url=='Top':
                popular = tv.popular(page=page)
            elif url=='Ratings':
                popular = tv.top_rated(page=page)
            elif url=='Search':
                if not selected_genre:
                    selected_genre=''
                    keyboard = xbmc.Keyboard(selected_genre, 'Enter Search')
                    keyboard.doModal()
                    if keyboard.isConfirmed() :
                           selected_genre = que(keyboard.getText().replace("'",""))
                           if selected_genre=='':
                            sys.exit()
                popular = tv.search(selected_genre,page=page)
            for p in popular:
                video_data={}
        
        
                video_data['title']=p.name
                video_data['imdb_id']=str(p.id)
                
                try:
                    video_data['year']=str(p.first_air_date.split("-")[0]) 
                except:
                    video_data['year']='0'
                    pass
                genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
                try:genere = u' / '.join([genres_list[x] for x in p.genre_ids])
                except:genere=''
               
                video_data['genre']=genere
                
                
                video_data['rating']=p.vote_average
                video_data['plot']=p.overview
                video_data['original_name']=p.original_name
                iconimage=base_icon_movies
                fanart=base_image_movies
                if p.poster_path:
                    iconimage='https://image.tmdb.org/t/p/original/'+p.poster_path
                if p.backdrop_path:
                    fanart='https://image.tmdb.org/t/p/original/'+p.backdrop_path
                description=p.overview
                
                all_d.append(addDir3( video_data['title'], 'seasons',9, iconimage,fanart,description,video_data=video_data,imdb_id=p.id))
            if url=='Search':
                url=str(selected_genre)+'$$$'+url
        elif url=='seasons':
            from resources.lib.modules.tmdbv3api import TV
            tv = TV()
            
            video_data_pre=json.loads(video_data)
            logging.warning(video_data_pre)
            id=video_data_pre['imdb_id']
            show=tv.details(id)
            for data in show['seasons']:
                video_data={}
        
        
                video_data['title']='Season '+str(data['season_number'])
                video_data['Season']=str(data['season_number'])
                video_data['imdb_id']=str(id)
                video_data['backdrop_path']=show['backdrop_path']
                if data['air_date']!=None:
                     video_data['year']=str(data['air_date'].split("-")[0])
                else:
                   video_data['year']=0
                
                
                
               
                video_data['plot']=data['overview']
                video_data['original_name']=video_data_pre['original_name']
                iconimage=base_icon_tv
                fanart=base_image_tv
                if data['poster_path']:
                    iconimage='https://image.tmdb.org/t/p/original/'+data['poster_path']
                if show['backdrop_path']:
                    fanart='https://image.tmdb.org/t/p/original/'+show['backdrop_path']
                description=data['overview']
                
                all_d.append(addDir3( video_data['title'], 'episodes',9, iconimage,fanart,description,video_data=video_data,imdb_id=id))
        elif url=='episodes':
            from resources.lib.modules.tmdbv3api import Season
            tv = Season()
            
            video_data_pre=json.loads(video_data)
            id=video_data_pre['imdb_id']
            season=video_data_pre['Season']
            show=tv.details(id,season)
     
            for data in show['episodes']:
                video_data={}
        
                
                
                video_data['title']=data['name']
                video_data['Season']=str(season)
                video_data['Episode']=data['episode_number']
                video_data['imdb_id']=str(id)
                
                if data['air_date']!=None:
                     video_data['year']=str(data['air_date'].split("-")[0])
                else:
                   video_data['year']=0
                
                
                
               
                video_data['plot']=data['overview']
                video_data['original_title']=video_data_pre['original_name']
                video_data['TVshowtitle']=video_data_pre['original_name']
                iconimage=base_icon_tv
                fanart=base_image_tv
                if show['poster_path']:
                    iconimage='https://image.tmdb.org/t/p/original/'+show['poster_path']
                if data['still_path']:
                    fanart='https://image.tmdb.org/t/p/original/'+data['still_path']
                
                description=data['overview']
                
                all_d.append(addLink( video_data['title'], 'www',4, iconimage,fanart,description,video_data,imdb_id=id))
        elif url=='Genres':
            from resources.lib.modules.tmdbv3api import Genre
            genre=Genre()
            all_id=[]
            all_n=[]
            for items in genre.tv_list():
                all_id.append(items['id'])
                all_n.append(items['name'])
            if not selected_genre:
                ret=xbmcgui.Dialog().select("Choose", all_n)
                if ret!=-1:
                    
                      selected_genre=all_id[ret]
                    
                else:
                    return 0
            from resources.lib.modules.tmdbv3api import Discover
            discover=Discover()
            movies = discover.discover_tv_shows({
                'with_genres': int(selected_genre),
                'sort_by': 'popularity.desc',
                'page':page
            })
            for item in movies:
                video_data={}
        
        
                video_data['title']=item['name']
                video_data['imdb_id']=str(item['id'])
                try:
                    video_data['year']=str(item['release_date'].split("-")[0])
                except:
                    video_data['year']='0'
                genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
                try:genere = u' / '.join([genres_list[x] for x in item['genre_ids']])
                except:genere=''
                 
                video_data['genre']=genere
                
                
                video_data['rating']=item['vote_average']
                video_data['plot']=item['overview']
                video_data['original_name']=item['original_name']
                iconimage=base_icon_movies
                fanart=base_image_movies
                if item['poster_path']:
                    iconimage='https://image.tmdb.org/t/p/original/'+item['poster_path']
                if item['backdrop_path']:
                    fanart='https://image.tmdb.org/t/p/original/'+item['backdrop_path']
                description=item['overview']
                all_d.append(addDir3( video_data['title'], 'seasons',9, iconimage,fanart,description,video_data=video_data,imdb_id=item['id']))
            url=str(selected_genre)+'$$$'+url
        elif url=='Years':
            
            if not selected_genre:
                all_years=[]
                import datetime
                all_d=[]
                now = datetime.datetime.now()
                for year in range(now.year,1970,-1):
                     all_years.append(str(year))
                ret= xbmcgui.Dialog().select("Choose", all_years)
                if ret!=-1:
                    
                      selected_genre=all_years[ret]
                    
                else:
                    return 0
            from resources.lib.modules.tmdbv3api import Discover
            discover=Discover()
            movies = discover.discover_tv_shows({
                'first_air_date_year': int(selected_genre),
                'sort_by': 'popularity.desc',
                'page':page
            })
            for item in movies:
                video_data={}
        
        
                video_data['title']=item['name']
                video_data['imdb_id']=str(item['id'])
                try:
                    video_data['year']=str(item['first_air_date'].split("-")[0])
                except:
                    video_data['year']='0'
                genres_list= dict([(i['id'], i['name']) for i in html_g['genres'] \
                    if i['name'] is not None])
                try:genere = u' / '.join([genres_list[x] for x in item['genre_ids']])
                except:genere=''
                 
                video_data['genre']=genere
                
                
                video_data['rating']=item['vote_average']
                video_data['plot']=item['overview']
                video_data['original_name']=item['original_name']
                iconimage=base_icon_movies
                fanart=base_image_movies
                if item['poster_path']:
                    iconimage='https://image.tmdb.org/t/p/original/'+item['poster_path']
                if item['backdrop_path']:
                    fanart='https://image.tmdb.org/t/p/original/'+item['backdrop_path']
                description=item['overview']
                all_d.append(addDir3( video_data['title'], 'seasons',9, iconimage,fanart,description,video_data=video_data,imdb_id=item['id']))
            url=str(selected_genre)+'$$$'+url
    if url!='seasons' and url!='episodes':
        all_d.append(addDir3( "[COLOR lightblue]Next page[/COLOR]", url,9, base_icon_movies,base_image_movies,tv_movie,page=str(int(page)+1)))
    
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
                
def last_played():
    try:
        from sqlite3 import dbapi2 as database
    except:
        from pysqlite2 import dbapi2 as database
    cacheFile=os.path.join(user_dataDir,'database.db')
    dbcon = database.connect(cacheFile)
    dbcur = dbcon.cursor()
   
    
    dbcur.execute("SELECT * FROM Lastlinkmovie")
    match = dbcur.fetchone()
    all_d=[]
    if match!=None:
        f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match
        video_data={}
        video_data['title']=name
        video_data['year']=show_original_year
        if season!='0':
            video_data['Season']=season
            video_data['Episode']=episode
            video_data['TVshowtitle']=original_title
            
        video_data['imdb_id']=id
            
        all_d.append(addLink( name, url,13, iconimage,fanart,description,video_data,imdb_id=id))
    dbcur.execute("SELECT * FROM Lastlinktv")
    match = dbcur.fetchone()
    if match!=None:
        f_name,name,url,iconimage,fanart,description,data,season,episode,original_title,saved_name,heb_name,show_original_year,eng_name,isr,prev_name,id=match
        video_data={}
        video_data['title']=name
        video_data['year']=show_original_year
        video_data['original_title']=original_title
        if season!='0':
            video_data['Season']=season
            video_data['Episode']=episode
            video_data['TVshowtitle']=original_title
            video_data['original_name']=original_title
        video_data['imdb_id']=id
            
        all_d.append(addLink( name, url,13, iconimage,fanart,description,video_data,imdb_id=id))
    xbmcplugin .addDirectoryItems(int(sys.argv[1]),all_d,len(all_d))
    dbcur.close()
    dbcon.close()
def resolve_play(video_data,url,iconimage,fanart,description):
    global playback_url
    url=base64.b64decode(url)
    logging.warning(url)
    
    video_data=json.loads(video_data)
    logging.warning(video_data)
    if 'TVshowtitle' not in video_data:
        logging.warning('Movie link')
        season=None
        episode=None
        tv_movie='movie'
    else:
        season=video_data['Season']
        episode=video_data['Episode']
        tv_movie='tv'
    thread=[]
    thread.append(Thread(show_new_window,tv_movie, video_data['imdb_id'], season, episode))
    #show_new_window(tv_movie, video_data['imdb_id'], season, episode)
    thread[0].start()
    if 'RD_' in url:
        url=url.replace('RD___','')
       
        from resources.lib.debrid.realdebrid import RealDebrid as debrid_function
    elif 'AD_' in url:
        url=url.replace('AD___','')
        
        from resources.lib.debrid.alldebrid import AllDebrid as debrid_function
    elif 'PM_' in url:
        url=url.replace('PM___','')
        from resources.lib.debrid.premiumize import Premiumize as debrid_function
    
    l_hash=url.split('btih:')[1]
    if '&' in l_hash:
        l_hash=l_hash.split('&')[0]
    playback_url = debrid_function().resolve_magnet(url, l_hash, season, episode, video_data['title'])
    get_sources(json.dumps(video_data),iconimage,fanart,description,just_play=True)
    
    
params=get_params()

url=None
name=None
mode=0
iconimage=None
fanart=None
description=None
data=None
page=0
imdb_id=''
video_data=''
try:
        url=unque(params["url"])
except:
        pass
try:
        name=unque(params["name"])
except:
        pass
try:
        iconimage=unque(params["iconimage"])
except:
        pass
try:        
        mode=int(params["mode"])
except:
        pass
try:        
        fanart=unque(params["fanart"])
except:
        pass
try:        
        description=unque(params["description"])
except:
        pass
try:        
        data=unque(params["data"])
except:
        pass
try:        
        page=unque(params["page"])
except:
        pass
try:        
        imdb_id=(params["imdb_id"])
except:
        pass
try:        
        season=(params["season"])
except:
        pass
try:        
        video_data=unque(params["video_data"])
except:
        pass

logging.warning('mode:'+str(mode))
if mode==0 :
        main_menu()
elif mode==2:
    categories(url)
elif mode==3:
    movies_data(url,page,description)
elif mode==4:
    get_sources(video_data,iconimage,fanart,description)
elif mode==5:
    get_seasons(iconimage,fanart,description,imdb_id)
elif mode==6:
    get_series(imdb_id,season)
elif mode==7:
    ClearCache()
elif mode==8:
    if name=='rd':
        from resources.lib.debrid.realdebrid import RealDebrid as debrid_function
        debrid_function().reset_authorization()
        #from resources.lib.modules.debridcheck import RDapi
        #RDapi().auth()
    elif name=='ad':
        from resources.lib.debrid.alldebrid import AllDebrid as debrid_function
        debrid_function().revoke_auth()
    elif name=='pm':
        from resources.lib.debrid.premiumize import Premiumize as debrid_function
        debrid_function().revoke_auth()
elif mode==9:
    tmdb_data(url,page,description,video_data)
elif mode==10:
    show_updates(force=True)
elif mode==11:
    if name=='rd':
        from resources.lib.debrid.realdebrid import RealDebrid as debrid_function
        debrid_function().auth()
        #from resources.lib.modules.debridcheck import RDapi
        #RDapi().auth()
    elif name=='ad':
        from resources.lib.debrid.alldebrid import AllDebrid as debrid_function
        debrid_function().auth()
    elif name=='pm':
        from resources.lib.debrid.premiumize import Premiumize as debrid_function
        debrid_function().auth()
elif mode==12:
    last_played()
elif mode==13:
    resolve_play(video_data,url,iconimage,fanart,description)
elif mode==180:
      try:
        path=xbmc_tranlate_path('special://home/addons/script.module.resolveurl/lib')
        sys.path.append( path)
        path=xbmc_tranlate_path('special://home/addons/script.module.six/lib')
        sys.path.append( path)
        path=xbmc_tranlate_path('special://home/addons/script.module.kodi-six/libs')
        sys.path.append( path)
        import resolveurl
        resolveurl.display_settings()
      except:
        pass
if mode==5:
    xbmcplugin.setContent(int(sys.argv[1]), 'seasons')
elif mode==6 or url=='episodes':
    xbmcplugin.setContent(int(sys.argv[1]), 'episodes')
else:
    xbmcplugin.setContent(int(sys.argv[1]), 'movies')
    
xbmcplugin.endOfDirectory(int(sys.argv[1]))

if mode==None:
    thread=[]
    thread.append(Thread(show_updates))
    thread[len(thread)-1].setName('Show updates')
    thread[0].start()